Source: https://github.com/ryannair05/AudioSnapshotServer2
Commit: 20d26f5061fa7db132da5148e18d814947f1905e

Through Lunora beta4, runtime sources were unchanged. Packaging changes: selected SDK, selectable Rootless/RootHide scheme, removed upstream device address, installed license and provenance, version suffix. No install/restart script added.

From Lunora 1.0.8 beta4, the main aggregate build stages this component inside the Lunora DEB. That beta4 runtime and injection filter were unchanged; its standalone control file is not used for aggregate packaging.

Local diagnostic changes after beta4: CaptureEngine.cpp and FeatureServer.cpp add control-queue metadata counters and bounded unified-log records, declared in ServerInternal.h. Build with LUNORA_AUDIO_DIAGNOSTICS=1 to enable; default is 0. At most 24 control-queue records plus two startup records per selected process launch. No PCM, waveform values, app names or session identities are logged. AudioUnit render hooks, source selection within the chosen process, supported formats and canonical MSHFProtocol.h are unchanged. No timer or install/restart script added.

Beta6 process-owner candidate: the filter includes only mediaserverd and audiomxd. A typed call to Apple's audiomxd_enabled query selects exactly one process before infrastructure/hook setup; absent query retains mediaserverd. ProcessPolicy.h is covered by sanitizer-enabled host tests. Startup diagnostics additionally report owner selection and whether each original hook trampoline was supplied. This mirrors the AudioToolboxServerInit branches in the user's iOS 17.3.1 system binaries; successful capture on the selected process still requires device validation.
