#ifdef SHOULD_COMPILE_LOOKIN_SERVER 

//
//  LookinServer.h
//  LookinServer
//
//  Created by Li Kai on 2019/7/20.
//  https://lookin.work
//

#ifndef LookinServer_h
#define LookinServer_h


#endif /* LookinServer_h */

#endif /* SHOULD_COMPILE_LOOKIN_SERVER */
