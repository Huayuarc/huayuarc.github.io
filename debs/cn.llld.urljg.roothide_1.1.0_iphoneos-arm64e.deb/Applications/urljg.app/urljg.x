<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Product</key>
	<string>urljg</string>
	<key>BundleIdentifier</key>
	<string>cn.llld.urljg.roothide</string>
	<key>PackageIdentifier</key>
	<string>cn.llld.urljg.roothide</string>
	<key>Executable</key>
	<string>urljg</string>
	<key>ApplicationDirectory</key>
	<string>urljg.app</string>
	<key>URLScheme</key>
	<string>urljgrh</string>
	<key>GuardDylib</key>
	<string>URLJGGuard.dylib</string>
	<key>GuardFilterPlist</key>
	<string>URLJGGuard.plist</string>
	<key>OfficialStoreURL</key>
	<string>sileo://package/cn.llld.urljg.roothide</string>
</dict>
</plist>
