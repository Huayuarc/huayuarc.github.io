#!/bin/bash

# ================================================
# QQ:478066693
#   民间布斯
# Theos 安装脚本 - 越狱设备专用版本
# ================================================

# 设置 Theos 的安装路径
THEOS_PATH="/opt/theos"

# 检查是否以 root 权限运行（越狱设备专用检查）
if [ "$EUID" -ne 0 ]; then
    echo "检测到非root权限运行..."
    
    # 检查是否在越狱环境中
    if [ -f "/usr/bin/apt-get" ] || [ -f "/usr/bin/cydia" ]; then
        echo "检测到越狱环境，尝试获取root权限..."
        
        # 尝试使用su命令获取root权限
        if command -v su &> /dev/null; then
            echo "正在使用su命令获取root权限..."
            exec su -c "$0 $@" root
        fi
        
        # 尝试使用sudo重新执行
        if command -v sudo &> /dev/null; then
            echo "正在使用sudo重新执行脚本..."
            exec sudo "$0" "$@"
        fi
        
        echo "无法获取root权限，请确保应用程序以root权限运行"
        echo "或者手动执行: su -c '$0' root"
    else
        echo "请使用 sudo 或以 root 权限运行此脚本。"
    fi
    exit 1
fi

echo "✓ 当前以root权限运行，开始Theos安装..."

# 更新包管理器
echo "正在更新包管理器..."
if command -v apt-get &> /dev/null; then
    sudo apt-get update
elif command -v yum &> /dev/null; then
    sudo yum update -y
elif command -v brew &> /dev/null; then
    brew update
else
    echo "未找到支持的包管理器（apt-get, yum, brew）。请手动更新你的系统。"
    exit 1
fi

# 安装必要的依赖
echo "正在安装必要的依赖..."
if command -v apt-get &> /dev/null; then
    sudo apt-get install -y git unzip wget
elif command -v yum &> /dev/null; then
    sudo yum install -y git unzip wget
elif command -v brew &> /dev/null; then
    brew install git unzip wget
else
    echo "未找到支持的包管理器（apt-get, yum, brew）。请手动安装 git, unzip, wget。"
    exit 1
fi

# 设置 Theos 环境变量（系统级别）
echo "正在设置 Theos 环境变量..."

# 创建系统级别的环境变量文件
ENV_FILE="/etc/profile.d/theos.sh"
echo "export THEOS=$THEOS_PATH" > "$ENV_FILE"
echo "export PATH=\$THEOS_PATH/bin:\$PATH" >> "$ENV_FILE"
chmod 644 "$ENV_FILE"

# 同时更新用户级别的配置
if [ -f "$HOME/.bashrc" ]; then
    echo "export THEOS=$THEOS_PATH" >> "$HOME/.bashrc"
    echo "export PATH=\$THEOS_PATH/bin:\$PATH" >> "$HOME/.bashrc"
elif [ -f "$HOME/.zshrc" ]; then
    echo "export THEOS=$THEOS_PATH" >> "$HOME/.zshrc"
    echo "export PATH=\$THEOS_PATH/bin:\$PATH" >> "$HOME/.zshrc"
fi

# 立即应用环境变量
export THEOS=$THEOS_PATH
export PATH=$THEOS_PATH/bin:$PATH

# 检查是否已经安装了 Theos
if [ -d "$THEOS_PATH" ]; then
    echo "Theos 已经安装在 $THEOS_PATH。是否需要重新安装？(y/n)"
    read -r REPLY
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
    rm -rf "$THEOS_PATH"
fi

# 备用 SDKs 下载地址
#https://gitee.com/yhmlg003/theos.git
#https://github.com/theos/theos.git

# 克隆 Theos 仓库
echo "正在克隆 Theos 仓库..."
git clone --recursive https://gitee.com/yhmlg003/theos.git "$THEOS_PATH"
if [ $? -ne 0 ]; then
    echo "克隆 Theos 仓库失败。请检查你的网络连接或仓库 URL。"
    exit 1
fi

# 进入 Theos 目录
cd "$THEOS_PATH" || { echo "无法进入 Theos 目录 $THEOS_PATH"; exit 1; }


# 备用 SDKs 下载地址
#https://github.com/theos/sdks/archive/refs/heads/master.zip
#https://gitee.com/yhmlg003/sdks/repository/archive/master.zip

# 下载 SDKs 压缩包
SDK_URL="https://gitee.com/yhmlg003/sdks/repository/archive/master.zip"
SDK_ZIP="master.zip"
echo "正在下载 SDKs 压缩包..."
curl -LO "$SDK_URL" -C - --output "$SDK_ZIP"
if [ $? -ne 0 ]; then
    echo "下载 SDKs 压缩包失败。尝试使用 wget..."
    if ! wget -O "$SDK_ZIP" "$SDK_URL"; then
        echo "下载 SDKs 压缩包失败。请检查你的网络连接或 URL。"
        exit 1
    fi
fi

# 解压 SDKs 压缩包
TMP_DIR="$THEOS_PATH/tmp"
mkdir -p "$TMP_DIR"
echo "正在解压 SDKs 压缩包..."
unzip "$SDK_ZIP" -d "$TMP_DIR"
if [ $? -ne 0 ]; then
    echo "解压 SDKs 压缩包失败。"
    exit 1
fi

# 移动 SDKs 文件
SDK_DEST="$THEOS_PATH/sdks"
mkdir -p "$SDK_DEST"
echo "正在移动 SDKs 文件..."
mv "$TMP_DIR/sdks-master"/*.sdk "$SDK_DEST"
if [ $? -ne 0 ]; then
    echo "移动 SDKs 文件失败。"
    exit 1
fi

# 删除临时目录和压缩包
echo "正在删除临时目录和压缩包..."
rm -r "$TMP_DIR"
rm "$SDK_ZIP"

# 给予执行权限
echo "正在给予 Theos 执行权限..."
chmod -R +x "$THEOS_PATH"

# 完成安装
echo "Theos 安装完成！"
echo "请确保将以下内容添加到你的 shell 配置文件中（如 ~/.bashrc 或 ~/.zshrc）："
echo "export THEOS=$THEOS_PATH"
echo "export PATH=\$THEOS/bin:\$PATH"
echo "然后执行 source ~/.bashrc 或 source ~/.zshrc 以应用更改。"