#import <UIKit/UIKit.h>

static const int kBackgroundColorCalculation = 0;
static const int kPrimaryColorCalculation = 1;
static const int kSecondaryColorCalculation = 2;

@interface PHXColorUtils : NSObject
+ (UIColor *)colorFromHex:(NSString *)hex;
+ (NSString *)hexFromColor:(UIColor *)color;
+ (UIColor *)colorFromImage:(UIImage *)image calculation:(int)calculation dimension:(int)dimension flexibility:(int)flexibility range:(int)range;
+ (UIColor *)colorWithMinimumSaturation:(UIColor *)color withSaturation:(double)saturation;
@end