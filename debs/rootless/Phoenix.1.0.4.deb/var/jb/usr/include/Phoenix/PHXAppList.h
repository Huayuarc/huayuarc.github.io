#import <UIKit/UIKit.h>
#import "PHXImage.h"

@interface LSApplicationProxy : NSObject
@property (nonatomic, copy, setter=_setLocalizedName:) NSString *localizedName;
@property (nonatomic, readonly) NSString *bundleIdentifier;
@end

@interface LSApplicationWorkspace
+ (id)defaultWorkspace;
- (id)allApplications;
@end

@interface PHXAppList : NSObject
+ (NSArray *)blacklistedApplications;
+ (NSMutableArray *)applications;
+ (BOOL)shouldListApp:(NSString *)bundleID;
+ (NSMutableArray *)sortArray:(NSMutableArray *)array;
@end