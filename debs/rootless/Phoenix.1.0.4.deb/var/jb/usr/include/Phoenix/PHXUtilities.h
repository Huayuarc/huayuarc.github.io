#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <rootless.h>
#import <spawn.h>

@interface PHXUtilities : NSObject
+ (CGSize)expectedLabelSize:(UILabel *)label;
+ (void)respring;
+ (void)reboot;
+ (void)safemode;
+ (void)shutdown;
+ (void)uicache;
@end