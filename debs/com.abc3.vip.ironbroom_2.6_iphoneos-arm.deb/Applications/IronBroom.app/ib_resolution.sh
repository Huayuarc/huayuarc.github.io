#!/bin/sh

find_defaults() {
    if [ -x /usr/bin/defaults ]; then
        echo "/usr/bin/defaults"
        return 0
    fi
    if [ -x /var/jb/usr/bin/defaults ]; then
        echo "/var/jb/usr/bin/defaults"
        return 0
    fi
    echo "defaults"
    return 0
}

find_killall() {
    if [ -x /usr/bin/killall ]; then
        echo "/usr/bin/killall"
        return 0
    fi
    if [ -x /var/jb/usr/bin/killall ]; then
        echo "/var/jb/usr/bin/killall"
        return 0
    fi
    echo "killall"
    return 0
}

DEFAULTS_BIN="$(find_defaults)"
KILLALL_BIN="$(find_killall)"

PLIST="/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist"
BACKUP="/var/mobile/backup-iomobile.plist"

if [ -f "$PLIST" ] && [ ! -f "$BACKUP" ]; then
    cp "$PLIST" "$BACKUP" 2>/dev/null || true
fi

MODE="$1"

if [ "$MODE" = "reset" ]; then
    "$DEFAULTS_BIN" delete com.apple.iokit.IOMobileGraphicsFamily canvas_width 2>/dev/null || true
    "$DEFAULTS_BIN" delete com.apple.iokit.IOMobileGraphicsFamily canvas_height 2>/dev/null || true
    "$DEFAULTS_BIN" delete com.apple.iokit.IOMobileGraphicsFamily scale 2>/dev/null || true
else
    WIDTH="$1"
    HEIGHT="$2"
    if [ -z "$WIDTH" ] || [ -z "$HEIGHT" ]; then
        exit 1
    fi
    "$DEFAULTS_BIN" write com.apple.iokit.IOMobileGraphicsFamily canvas_width -int "$WIDTH"
    "$DEFAULTS_BIN" write com.apple.iokit.IOMobileGraphicsFamily canvas_height -int "$HEIGHT"
    "$DEFAULTS_BIN" write com.apple.iokit.IOMobileGraphicsFamily scale -float 3.0
fi

sleep 1
"$KILLALL_BIN" -9 backboardd 2>/dev/null || true
"$KILLALL_BIN" -9 SpringBoard 2>/dev/null || true
