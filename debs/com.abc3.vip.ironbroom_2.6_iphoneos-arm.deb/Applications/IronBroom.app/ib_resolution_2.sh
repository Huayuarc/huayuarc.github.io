#!/bin/sh

/bin/sh /Applications/IronBroom.app/ib_resolution.sh 1284 2778
