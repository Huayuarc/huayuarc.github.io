#!/bin/sh

/bin/sh /Applications/IronBroom.app/ib_resolution.sh 1290 2796
