#!/bin/sh

REQ_FILE="/var/mobile/ib_resolution_request"

while true; do
    if [ -f "$REQ_FILE" ]; then
        MODE="$(cat "$REQ_FILE" 2>/dev/null)"
        rm -f "$REQ_FILE"
        if [ "$MODE" = "reset" ]; then
            /bin/sh /Applications/IronBroom.app/ib_resolution.sh reset
        elif [ "$MODE" = "1" ]; then
            /bin/sh /Applications/IronBroom.app/ib_resolution_1.sh
        elif [ "$MODE" = "2" ]; then
            /bin/sh /Applications/IronBroom.app/ib_resolution_2.sh
        elif [ "$MODE" = "3" ]; then
            /bin/sh /Applications/IronBroom.app/ib_resolution_3.sh
        fi
    fi
    sleep 1
done

