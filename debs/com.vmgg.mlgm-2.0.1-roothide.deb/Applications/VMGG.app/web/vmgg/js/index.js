document.addEventListener('DOMContentLoaded', () => {
  let currentPath = '/';

  // UI Elements
  const breadcrumbEl = document.getElementById('breadcrumb');
  const fileListEl = document.getElementById('file-list');
  const emptyStateEl = document.getElementById('empty-state');
  const uploadInput = document.getElementById('upload-input');
  const btnRefresh = document.getElementById('btn-refresh');
  const btnNewFolder = document.getElementById('btn-new-folder');
  const dropzone = document.getElementById('dropzone');
  
  const modalOverlay = document.getElementById('modal-overlay');
  const modalTitle = document.getElementById('modal-title');
  const modalInput = document.getElementById('modal-input');
  const btnModalCancel = document.getElementById('modal-cancel');
  const btnModalConfirm = document.getElementById('modal-confirm');
  
  const toastEl = document.getElementById('toast');
  const progressContainer = document.getElementById('upload-progress-container');
  const progressFilename = document.getElementById('upload-filename');
  const progressPercentage = document.getElementById('upload-percentage');
  const progressBar = document.getElementById('upload-progress-bar');

  const moveBar = document.getElementById('move-bar');
  const moveBarName = document.getElementById('move-bar-name');
  const btnMoveCancel = document.getElementById('move-bar-cancel');
  const btnMoveConfirm = document.getElementById('move-bar-confirm');

  // 正在移动的文件（剪切-粘贴模式）：null = 未处于移动状态。
  let pendingMove = null;

  // Icons
  const ICON_FILE = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg>`;
  const ICON_FOLDER = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/></svg>`;
  const ICON_EDIT = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>`;
  const ICON_MOVE = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/></svg>`;
  const ICON_DELETE = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>`;

  function formatSize(bytes) {
    if (bytes >= 1e9) return (bytes / 1e9).toFixed(2) + ' GB';
    if (bytes >= 1e6) return (bytes / 1e6).toFixed(2) + ' MB';
    return (bytes / 1e3).toFixed(2) + ' KB';
  }

  let toastTimeout;
  function showToast(msg, isError = false) {
    toastEl.textContent = msg;
    if (isError) toastEl.classList.add('error');
    else toastEl.classList.remove('error');
    toastEl.classList.add('show');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => toastEl.classList.remove('show'), 3000);
  }

  // API Call Wrapper
  async function apiCall(endpoint, method, data = null) {
    try {
      let body = null;
      let headers = {};
      if (data) {
        body = new URLSearchParams();
        for (const key in data) body.append(key, data[key]);
        headers['Content-Type'] = 'application/x-www-form-urlencoded';
      }
      
      const res = await fetch(endpoint, { method, body, headers });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error ? errorData.error.message : res.statusText);
      }
      return await res.json();
    } catch (err) {
      showToast(err.message, true);
      throw err;
    }
  }

  // Load Directory
  async function loadPath(path) {
    try {
      const res = await fetch(`list?path=${encodeURIComponent(path)}`);
      if (!res.ok) throw new Error(res.statusText);
      const data = await res.json();
      
      currentPath = path;
      renderBreadcrumb();
      renderFiles(data);
      updateMoveBar();
    } catch (err) {
      showToast('获取目录失败: ' + err.message, true);
    }
  }

  function renderBreadcrumb() {
    breadcrumbEl.innerHTML = '';
    const parts = currentPath.split('/').filter(Boolean);
    
    const root = document.createElement('div');
    root.className = 'breadcrumb-item breadcrumb-root' + (parts.length === 0 ? ' active' : '');
    root.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>';
    root.title = '根目录';
    root.onclick = () => loadPath('/');
    breadcrumbEl.appendChild(root);

    let acc = '';
    parts.forEach((p, idx) => {
      const sep = document.createElement('span');
      sep.className = 'breadcrumb-sep';
      sep.textContent = '/';
      breadcrumbEl.appendChild(sep);

      acc += '/' + p;
      const el = document.createElement('div');
      el.className = 'breadcrumb-item' + (idx === parts.length - 1 ? ' active' : '');
      el.textContent = p;
      const targetPath = acc + '/';
      el.onclick = () => loadPath(targetPath);
      breadcrumbEl.appendChild(el);
    });
  }

  function renderFiles(files) {
    fileListEl.innerHTML = '';
    if (files.length === 0) {
      emptyStateEl.style.display = 'block';
    } else {
      emptyStateEl.style.display = 'none';
      files.forEach(f => {
        const isDir = f.size == null;
        const tr = document.createElement('tr');
        tr.className = 'file-row';
        tr.innerHTML = `
          <td class="cell-icon">${isDir ? ICON_FOLDER : ICON_FILE}</td>
          <td class="cell-name">${f.name}</td>
          <td class="cell-size">${isDir ? '--' : formatSize(f.size)}</td>
          <td class="cell-actions">
            <button class="action-btn" title="重命名" data-action="rename">${ICON_EDIT}</button>
            <button class="action-btn" title="移动" data-action="move">${ICON_MOVE}</button>
            <button class="action-btn danger" title="删除" data-action="delete">${ICON_DELETE}</button>
          </td>
        `;
        
        tr.querySelector('.cell-name').onclick = () => {
          if (isDir) {
            loadPath(f.path);
          } else {
            window.location.href = `download?path=${encodeURIComponent(f.path)}`;
          }
        };

        tr.querySelectorAll('.action-btn').forEach(btn => {
          btn.onclick = (e) => {
            e.stopPropagation();
            const action = btn.dataset.action;
            if (action === 'rename') {
              openModal('重命名', f.name, async (newName) => {
                await apiCall('move', 'POST', { oldPath: f.path, newPath: currentPath + newName });
                loadPath(currentPath);
              });
            }
            else if (action === 'move') {
              pendingMove = f;
              updateMoveBar();
              showToast('导航到目标目录后点「移动到此处」');
            }
            else if (action === 'delete') {
              if (confirm(`确定要删除 ${f.name} 吗？`)) {
                apiCall('delete', 'POST', { path: f.path }).then(() => loadPath(currentPath));
              }
            }
          };
        });

        fileListEl.appendChild(tr);
      });
    }
  }

  // 根据当前状态更新移动提示栏：显示正在移动的文件名，并在以下情况禁用
  // 「移动到此处」：① 目标目录与源目录相同（移动到原位置无意义）；
  // ② 把文件夹移动进它自身或其子目录（会造成循环）。
  // 统一用「带尾斜杠」目录形式比较，规避 currentPath 尾斜杠不一致的问题。
  function dirWithSlash(p) { return p.endsWith('/') ? p : p + '/'; }
  function updateMoveBar() {
    if (!pendingMove) { moveBar.style.display = 'none'; return; }
    moveBar.style.display = 'flex';
    moveBarName.textContent = pendingMove.name;
    const curDir = dirWithSlash(currentPath);
    const srcDir = pendingMove.path.slice(0, pendingMove.path.length - pendingMove.name.length);
    const isDir = (pendingMove.size == null);
    const selfPrefix = dirWithSlash(pendingMove.path);
    const intoSelf = isDir && curDir.startsWith(selfPrefix);
    btnMoveConfirm.disabled = (dirWithSlash(srcDir) === curDir) || intoSelf;
  }

  btnMoveCancel.onclick = () => { pendingMove = null; updateMoveBar(); };
  btnMoveConfirm.onclick = async () => {
    if (!pendingMove) return;
    btnMoveConfirm.disabled = true;
    try {
      const newPath = dirWithSlash(currentPath) + pendingMove.name;
      await apiCall('move', 'POST', { oldPath: pendingMove.path, newPath });
      pendingMove = null;
      loadPath(currentPath);
      showToast('已移动');
    } catch (err) {
      updateMoveBar();
    }
  };

  // Modal
  let modalCallback = null;
  function openModal(title, defaultVal, callback) {
    modalTitle.textContent = title;
    modalInput.value = defaultVal;
    modalCallback = callback;
    modalOverlay.classList.add('show');
    setTimeout(() => { modalInput.focus(); modalInput.select(); }, 100);
  }
  function closeModal() {
    modalOverlay.classList.remove('show');
    modalInput.blur();
  }
  btnModalCancel.onclick = closeModal;
  btnModalConfirm.onclick = async () => {
    const val = modalInput.value.trim();
    if (!val) return;
    btnModalConfirm.disabled = true;
    try {
      if (modalCallback) await modalCallback(val);
      closeModal();
    } finally {
      btnModalConfirm.disabled = false;
    }
  };
  modalInput.onkeydown = (e) => { if (e.key === 'Enter') btnModalConfirm.onclick(); };

  // Actions
  btnRefresh.onclick = () => loadPath(currentPath);
  btnNewFolder.onclick = () => openModal('新建文件夹', '新建文件夹', async (name) => {
    await apiCall('create', 'POST', { path: currentPath + name });
    loadPath(currentPath);
  });

  // Upload
  async function uploadFiles(fileList) {
    const files = Array.from(fileList);
    if (!files.length) return;

    progressContainer.style.display = 'block';

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      progressFilename.textContent = `上传中: ${file.name} (${i+1}/${files.length})`;
      progressBar.style.width = '0%';
      progressPercentage.textContent = '0%';

      await new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.upload.onprogress = (evt) => {
          if (evt.lengthComputable) {
            const pct = Math.round((evt.loaded / evt.total) * 100);
            progressBar.style.width = pct + '%';
            progressPercentage.textContent = pct + '%';
          }
        };
        xhr.onload = () => {
          if (xhr.status === 200) resolve();
          else reject(new Error('Upload failed'));
        };
        xhr.onerror = () => reject(new Error('Network error'));

        const fd = new FormData();
        fd.append('path', currentPath);
        fd.append('files[]', file);

        xhr.open('POST', 'upload');
        xhr.send(fd);
      }).catch(err => showToast(`上传 ${file.name} 失败: ` + err.message, true));
    }

    progressContainer.style.display = 'none';
    uploadInput.value = '';
    loadPath(currentPath);
  }

  uploadInput.onchange = (e) => {
    if (e.target.files.length) uploadFiles(e.target.files);
  };

  // 拖拽上传：点击拖拽区等同选择文件。
  dropzone.onclick = () => uploadInput.click();
  ['dragenter', 'dragover'].forEach(ev =>
    dropzone.addEventListener(ev, (e) => {
      e.preventDefault();
      dropzone.classList.add('dragover');
    })
  );
  ['dragleave', 'drop'].forEach(ev =>
    dropzone.addEventListener(ev, (e) => {
      e.preventDefault();
      dropzone.classList.remove('dragover');
    })
  );
  dropzone.addEventListener('drop', (e) => {
    if (e.dataTransfer.files.length) uploadFiles(e.dataTransfer.files);
  });

  // Theme Init
  const themes = ['light', 'dark', 'auto'];
  themes.forEach(t => {
    document.getElementById(`theme-${t}`).onclick = () => {
      localStorage.setItem('lc-theme', t);
      applyTheme(t);
      updateThemeButtons(t);
    };
  });
  function updateThemeButtons(theme) {
    document.querySelectorAll('.theme-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(`theme-${theme}`).classList.add('active');
  }
  updateThemeButtons(localStorage.getItem('lc-theme') || 'auto');

  // Initial Load
  loadPath('/');
});
