# TWEAK.md — shiv tweak development recipes

Read this BEFORE doing tweak work. Everything here was MEASURED on
device, not guessed. Written for the model; the user's own notes live
in `belgeler/`.

**Priority when sources disagree:**

1. **MEASUREMENT** — what you just read off the device
2. **RULE** — an absolute line in the system prompt
3. **RECIPE** — a pattern in this file

If a measurement contradicts a recipe, the MEASUREMENT wins and the
recipe is stale — say so, and tell the user which line to update.

---

## 0. FIRST: probe the environment, once

Never guess paths or tool availability. At the start of tweak work run
`shiv-ortam` (it sits next to the bundle; the prompt gives the absolute
path) and keep its result for the whole session — do not re-probe per
request. The user sees the same measurement with `/ortam`.

It ends with a RECOMMENDED FLOW: the exact build and install commands
for this device, chosen from what it just measured. Follow that rather
than picking a flow from this file by hand.

What it measures:

| Thing | How to read it |
|---|---|
| jailbreak kind | roothide / rootless / rootful |
| theos path + kind | `ls <theos>/vendor/mod/` → `roothide` present = fork |
| SDKs | `ls <theos>/sdks/` |
| toolchain | `command -v clang ldid make perl swift` |
| RootHide Patcher | `/Applications/Patcher.app/patch.sh` exists? (only relevant if you deliver to roothide) |
| oldabi | `OldABI.dylib` present? → if yes, device-built caps 0x00 tweaks run here (and need `Depends: …\| oldabi` to ship). See §1.6 |
| editing a file in place | **Never** `cmd file > file` - the shell truncates the target before the command reads it. Measured here: an `awk ... .zshrc > .zshrc` emptied the user's shell rc. Write to a temp file and `mv`. |
| backup before editing | `cp` to a NEW absolute path can fail on the FIRST try on RootHide: `cp: updating times for '/var/mobile/X': No such file or directory`, rc=1 **and no file**; the identical command then succeeds. `cat src > dst` works first time (measured 20 Sep 2026). Always `ls` the backup before touching the original - a backup you did not verify is not a backup |
| jbroot path | **Resolve it every time**: `ls -d /var/containers/Bundle/Application/.jbroot-*`. The suffix CHANGES (measured 20 Sep 2026: a reboot turned `.jbroot-4804A53C740654F3` into `.jbroot-F41C303B16BC773E`), so a path pasted from an earlier session or report is stale and every command using it fails with "No such file" |
| frida-server | Do NOT decide from `ps ax \| grep frida-server`: any command line containing that string matches (measured - the model's own `ps ax \| grep` command showed up in `ps` and was counted as a running server). Ask by process NAME (`pgrep -x frida-server`, `ps ax -o comm=`) or `launchctl list`. `shiv-frida-kur` already does this; **must be major 16** — shivfrida is linked against frida-core 16.x. A 17.x server (Sileo/build.frida.re latest) fails with "major versions match". `shiv-frida-kur` DIAGNOSES only (safe, changes nothing): binary/package/agent/plist/process, plus conflicts such as two binaries, an orphaned binary with no package, a package with no binary, a stale daemon or leftover debs. It then prints the command to run. Installing is a separate, explicit step - `sudo shiv-frida-kur --kur`: show the diagnosis, ask, and once the user agrees run it yourself (never hand them manual download steps, and never install without asking - leftovers from an earlier frida can silently produce a broken setup). It installs 16.1.4 (rootless: GitHub release deb; roothide: RootHide repo) and holds the package so Sileo cannot upgrade to 17.x. |
| shiv frida tools | `shiv-cek`, `shiv-oku`, `shiv-ekran`, `shiv-sinif` (on PATH). `shiv-sinif` reads the dyld cache (no frida); `shiv-cek`/`shiv-oku`/`shiv-ekran` need a matching frida-server |
| inject dir | `/usr/lib/TweakInject` |

---

## 1. BUILD + INSTALL

### 1.1 Which theos do you have

```
ls <theos>/vendor/mod/
  roothide rootless   → roothide FORK  (superset: does BOTH schemes)
  rootless            → standard theos (roothide scheme absent)
```

A standard theos fails with `'roothide' package scheme does not exist`.

### 1.2 Two flows

**A — roothide-native (fork only, no patcher):**

```
make THEOS=<fork> clean package THEOS_PACKAGE_SCHEME=roothide
  → iphoneos-arm64e deb
dpkg -i packages/<name>_iphoneos-arm64e.deb
```

**B — rootless + patcher (works with either theos):**

```
make THEOS=<theos> clean package THEOS_PACKAGE_SCHEME=rootless
  → iphoneos-arm64 deb
/Applications/Patcher.app/patch.sh <deb> <out.deb> AutoPatches
dpkg -i <out.deb>
```

`patch.sh` accepts a ROOTLESS input only. Give it an arm64e deb and it
prints `*** Not a rootless package!` and exits.

`dpkg -i` on an unpatched, non-roothide deb fails with `/Library`
"Operation not permitted". Either roothide-native or patch.sh — there
is no third way. Hand-placing files into `/usr/lib/TweakInject/` is a
last-resort test, not an install.

**Which flow is yours — decided by the TARGET jailbreak, not your build
device.** shiv-ortam already picks the right one; the rule behind it:

| Build device | Deliver to | Flow |
|---|---|---|
| rootless | rootless | standard theos, `SCHEME=rootless`. **No fork, no patcher, no roothide-native** — none of it applies. |
| rootless | roothide too | build `SCHEME=rootless`, then convert on a **roothide** device (`patch.sh`), or build with the fork. |
| roothide (fork) | roothide | `SCHEME=roothide` (flow A). |
| roothide (fork) | rootless too | same fork also builds `SCHEME=rootless`. |

The trap this fixes: on a **rootless** device the model used to recommend
the *roothide* theos fork and worry about the *patcher*. Neither is
needed for a rootless tweak — the roothide fork/patcher only matter when
the deliverable must run on a roothide device. Do not push a rootless
user toward `roothide/theos.git`; standard `theos/theos` is enough.

**"RootHide Patcher" — say the full name, and do not misdescribe it:**
- It is a **separate roothide app** (installed from Sileo, runs on a
  roothide device). It does **NOT** come bundled with theos, and it is
  **NOT** part of the SDK. Never tell a user "theos brings the patcher".
- Always write the full name **"RootHide Patcher"** (a bare "patcher"
  matches dozens of unrelated tools when searched).
- On a rootless device it is **not a missing requirement** — do not list
  it under "missing". It is situational: needed only to convert a
  rootless-scheme deb into a roothide-installable one.

**Confidence:** B has been used for dozens of builds over months and is
what shipped. A was measured 12 Sep 2026 (app + SpringBoard tweaks,
worked first try, no patch.sh). Both are valid; B is more battle-tested,
A is shorter. The older note claiming "rootless+patch is more stable"
belonged to a different theos install and never recorded a reason.

### 1.3 Arch: the dylib and the deb label are different things

- **dylib arch = the TARGET process's arch.** App is arm64 → `ARCHS = arm64`.
  SpringBoard is arm64e → `ARCHS = arm64e`. An arm64 dylib does not load
  into an arm64e process.
  (Cross-arch loading was seen lenient once in the other direction: an
  arm64e caps-0x00 tweak also loaded into the arm64 e-Nabız app. **Do
  NOT generalise this to "always build arm64e".** It was measured once
  and is the opposite of the expected behaviour; A11 and earlier devices
  have no arm64e at all, and an arm64e tweak loads nowhere on them. The
  rule stands: dylib arch = target process arch.)
- **deb label** is written by Theos from `THEOS_PACKAGE_SCHEME`. Theos
  IGNORES `Architecture:` in your `control` file — do not bother setting
  it. If the label comes out arm64e when you wanted rootless, the scheme
  is wrong; fix the scheme, not the control file.

So a SpringBoard tweak via flow B is `ARCHS = arm64e` **and**
`THEOS_PACKAGE_SCHEME=rootless` at the same time. That is not a
contradiction — arch ≠ label.

### 1.4 `make THEOS=` — not `THEOS= make`

```
make THEOS=/var/mobile/theos-roothide ...   command-line assignment, beats everything  ✓
THEOS=/var/mobile/theos-roothide make ...   environment var, a Makefile `export` overrides it  ✗
```

A Makefile line `export THEOS=/var/mobile/theos` silently wins over the
environment form. This cost a wasted rebuild.

**When you generate a Makefile, do NOT write `export THEOS=`.** Leave
THEOS to come from outside so switching toolchains is one flag.

### 1.5 Never trust `ls -t`

`ls -t packages/*.deb | head -1` gives the newest FILE, not the newest
BUILD. If the build failed, a stale deb is still there and gets
installed silently — this is the most repeated mistake in this project.

Instead: read the build output line

```
dm.pl: building package `...' in `./packages/<exact-name>.deb'
```

That line present = build succeeded, and it gives the exact path. No
line = build failed; do not go looking for a deb.

Before installing, verify the artifact actually contains your change:

```
strings <dylib> | grep <your marker>
otool -l <dylib> | grep -A2 LC_UUID     # changes on rebuild, not on copy
```

### 1.6 caps 0x00 — the real rule

The on-device toolchain emits arm64e with `caps 0x00` instead of `0x80`.
This is NOT a version problem: a newer clang will not fix it. Do not
suggest installing a different clang.

**Who this affects — measured, not assumed.** Across the tweaks this
project shipped, the split is clean:

| Tweak | Target | Device build? |
|---|---|---|
| EnabizShiv, ShivYTAlert, ExcelShiv, YandexNaviShiv | app (arm64) | yes — no PAC at all |
| ShivLockLabel | SpringBoard (arm64e), `%hook`, no `@""`, no blocks | yes — ran fine |
| ActionButtonFix | SpringBoard (arm64e), touches the triggers | this is the affected case |

The correlation, **7 real samples, zero exceptions**: an arm64e old-ABI
dylib with `__cfstring > 0` crashed in an arm64e host; one with
`__cfstring = 0` ran. `otool -l <dylib> | grep -c __cfstring`.

So the affected set is narrow: **only device-built arm64e tweaks that
touch a trigger.** App tweaks (arm64) are never affected. Plain
`%hook`/`%orig` SB tweaks with no `@""` and no block handed to the
system build and run on device without oldabi. Do NOT tell a user to
install oldabi for those — they do not need it.

`caps 0x00` on its own is HARMLESS. It is not a defect; it is a
dependency. The crash happens when the ObjC runtime tries to
AUTHENTICATE an `isa` pointer that OUR code wrote. There are TWO ways to
hand it one, and the first is far more common:

```
1. an @"..." NSString literal
   a static __NSCFConstantString baked into the binary; its isa is
   signed at compile time with the old scheme
   → CoreFoundation authenticates it → SIGBUS

2. giving an ObjC block to the SYSTEM (e.g. [block copy], or a block
   passed to a completion: parameter the system will copy)
   → libobjc authenticates the block's isa → SIGBUS
```

Everything else is safe — including things that look dangerous:

| Operation | isa authenticated? | Result |
|---|---|---|
| `object_setIvar(obj, iv, block)` | no — just writes the pointer | OK |
| `dispatch_async(q, ^{ })` | no — `_Block_copy` is plain C | OK |
| `dispatch_after_f`, `dlsym` | no object involved | OK |
| selector calls, `%hook`/`%orig`, reading ivars | system's own objects | OK |
| `stringWithUTF8String:` | the SYSTEM builds the object | OK |
| **`@"..."` literal** | **yes (CoreFoundation)** | **CRASH** |
| **`[block copy]`** | **yes (libobjc)** | **CRASH** |

Note the first row: writing a block into an ivar with `object_setIvar`
is SAFE — it only stores the pointer. It is `[copy]` (an `objc_msgSend`
that reads the isa) that crashes, not storing.

**Why `[copy]` crashes and `dispatch_async` does not:** `[blk copy]`
goes through `objc_msgSend`, which READS and authenticates the block's
isa → SIGBUS. `dispatch_async` goes through `_Block_copy` in
libsystem_blocks — plain C, no authentication → OK.

**arm64 hosts have no restriction at all.** App Store apps are arm64,
there is no PAC, none of this applies. Measured: a device-built tweak
with two blocks ran fine inside an arm64 app. Do NOT generalise "arm64e
is dangerous" to arm64 targets.

**`__cfstring` is the tell.** Correlation across 7 real samples, zero
exceptions: every arm64e old-ABI dylib with `__cfstring > 0` crashed in
an arm64e host; every one with `__cfstring = 0` ran. Check before you
ship a device-built arm64e system tweak:

```
otool -l <dylib> | grep -c __cfstring     # must be 0
```

#### Safe patterns (avoid trigger 1, the common one)

```objc
// instead of @"..."
static id nsstr(const char *s) {
    return ((id(*)(Class,SEL,const char*))objc_msgSend)(
        objc_getClass("NSString"),
        sel_registerName("stringWithUTF8String:"), s);
}
// instead of [block copy]
dispatch_async(queue, ^{ ... });   // routed through _Block_copy
```

#### OldABI removes both limits

`OldABI.dylib` hooks `dlopen`; when an old-ABI binary loads it patches
libobjc and CoreFoundation, rewriting `autda` (authenticate) into
`xpacd` (strip the signature, do not authenticate). Those two targets
map exactly onto the two crash modes.

```
oldabi NOT installed  → an arm64e caps 0x00 tweak that touches either
                        trigger CRASHES SpringBoard → Safe Mode
oldabi installed      → both triggers are harmless
```

Measured 14 Sep 2026 (RootHide): same binary, only `OldABI.dylib`
renamed in and out — the path crashed with it off, worked with it on.
Four such single-variable pairs.

**The package name varies by jailbreak — measure, do not assume:**

```
RootHide         oldabi (2.0.1+roothide-1), RootHide's own repo
                 (default repo — usually already present)
Dopamine         "Legacy arm64e Support", ElleKit repo
                 → https://ellekit.space — but recent Dopamine may ship
                 an embedded fix; the package can be gone.
                 MEASURE: dpkg -l | grep -i 'oldabi\|legacy arm64e'
XinaA15          oldabi-xina (XinaA15 repo)
Taurine / rootful  embedded patch, no package needed
```

Verified 15 Sep 2026 against NightwindDev's `Tweak-Tutorial/oldabi.md`,
the roothide `Packages` list, and ellekit.space.

Two names, one package — say BOTH or the user gets stuck:
- **Sileo title (what they search):** "Legacy arm64e Support"
- **package id (what `Depends` / `dpkg` use):** `oldabi`

It is not free. OldABI does instruction replacement, which can cause a
spinlock; the embedded Dopamine fix does not.

**Why it does NOT work for Swift tweaks.** OldABI only patches the
Objective-C paths — it rewrites `autda`→`xpacd` inside libobjc and
CoreFoundation, which is exactly where an ObjC `isa` gets authenticated.
Swift does not go through those. The Swift runtime authenticates its own
pointers — type metadata, protocol/witness tables, class metadata — in
libswiftCore, which OldABI never hooks. So a device-built (caps 0x00)
Swift arm64e tweak still SIGBUSes in a Swift-runtime path even with
OldABI installed (this also hits anything pulling in Swift, e.g. Cephei).
The honest fix for a Swift tweak that needs the old ABI: **build it on
Mac (caps 0x80)** — there is no on-device bridge for the Swift side.
(Verified 16 Sep 2026 against NightwindDev's `oldabi.md` and the
qnblackcat/allemande notes.)

**Correct `Depends` line — do NOT write plain `oldabi`:**

```
Depends: firmware (<< 15.0) | cy+cpu.arm64v8 | oldabi
```

Reads as: either pre-iOS-15, OR arm64 (no PAC), OR oldabi installed —
any ONE suffices. Plain `Depends: oldabi` needlessly excludes arm64
devices and old iOS.

#### Deciding where to build — device first, Mac is the LAST resort

Read the CODE, not the target. Build on the device whenever you can; a
Mac build is the fallback only when neither of the two device paths
works.

| Situation | Where |
|---|---|
| target is an **arm64** app (App Store) | **device** — no PAC, no limits |
| arm64e system proc, no `@""` and no block handed to the system | **device** |
| arm64e system proc, `@""` present | rewrite with `nsstr()` → **device** |
| arm64e system proc, hands a block to the system, **oldabi installed** | **device** — oldabi bridges it |
| arm64e, blocks unavoidable, **no oldabi** and cannot depend on it | Mac (caps 0x80) — last resort |

The target process alone does not decide; the two triggers do. A
SpringBoard tweak builds on the device fine if it avoids both, or if
`oldabi` is present — measured repeatedly.

**⚠ MEASUREMENT CONFOUND — remember this.** If `oldabi` is installed on
your build device, a caps 0x00 tweak with `@""` or blocks will run and
you will conclude "it works" — but that is oldabi bridging it, not the
tweak being safe. Every caps 0x00 tweak this project shipped was in fact
tested on a device that had oldabi installed. Before trusting an
"it works", check:

```
dpkg -l | grep -i 'oldabi\|legacy arm64e'
```

If oldabi is there, your "it works" only proves it works ON A DEVICE
WITH OLDABI. To know the truth, do the single-variable A/B: rename
`OldABI.dylib` out, respring, test; rename it back.

#### Distribution consequence — YOUR USERS need oldabi too

This is the part a developer must not miss. If you build a caps 0x00
arm64e tweak that touches either trigger and it works on your device
because oldabi is installed, then **every user who installs it also
needs oldabi**, or it will Safe Mode THEIR device. Silently shipping
that hands them the crash you avoided.

Two honest ways to ship:

```
1. Depend on oldabi (device build kept)
   Depends: firmware (<< 15.0) | cy+cpu.arm64v8 | oldabi
   — pre-iOS-15 OR arm64 (no PAC) OR oldabi: any one suffices.
   The user's package manager pulls oldabi automatically.
   Cost: oldabi changes system-wide runtime behaviour (it does
   instruction replacement, which can spinlock on some setups).

2. Build on a Mac (caps 0x80) and depend on NOTHING
   The tweak is genuinely self-contained; no user needs oldabi.
   This is why the Mac build exists — not because device builds
   are worse, but because a distributed package should not force a
   runtime shim on its users.
```

For something only YOU run, device + oldabi is fine and faster. For
something you DISTRIBUTE, either declare the `oldabi` dependency
honestly or build on the Mac. Do not ship a tweak that quietly needs
oldabi without saying so.

### 1.6b Before installing: is an older build already in?

Check first — it is the same trap every rebuild:

```
dpkg -l | grep -i <name>          # an earlier version of THIS tweak?
ls /usr/lib/TweakInject/          # anything hooking the same thing?
```

If a previous tweak hooks the SAME method, Substrate/ElleKit **chains**
the hooks: every hook stores the previous implementation and calls it,
so BOTH run. You do not get an error and nothing is disabled — you get
the effect twice (two labels stacked at the same spot, measured with
ShivLockLabel + ShivLockVersion). Remove the old package first
(`dpkg -r <package>`) unless you genuinely want both.

Safe Mode is a different failure: it needs a tweak that CRASHES
SpringBoard (e.g. the caps-0x00 block case in §1.6), not a duplicate
hook.

### 1.6c Substrate, ElleKit and Safe Mode — measured

These are Substrate-API tweaks and ElleKit is what provides that API
here (not a separate Substrate install):

```
/usr/lib/libsubstrate.dylib -> /usr/lib/libellekit.dylib   (package: ellekit)
ellekit also ships: CydiaSubstrate.framework, /usr/lib/TweakInject,
                    /usr/lib/ellekit/MobileSafety.dylib
```

Safe Mode is real and file-flagged. `TweakInject` checks `_MSSafeMode`
/ `_SafeMode` against the marker file, and `MobileSafety` shows:

> *"You've entered safe mode. SpringBoard tweaks will not get injected
> until you respring your device. You can select Dismiss to safely
> remove your broken tweaks."*

```
marker: /var/mobile/.eksafemode
```

So if the device is in Safe Mode: SpringBoard tweaks are NOT injected
until a respring — do not conclude "my tweak did not load, the build is
wrong". Check the marker first, remove the offending package
(`dpkg -r <package>`), then ask the user to respring.

`/device` also reports how many tweaks hook one process — the cheap way
to spot a crowded target before adding one more.

### 1.7 Distribution: publish the ROOTLESS deb

```
rootless deb  → rootless user installs it directly
              → roothide user converts it with patch.sh
roothide deb  → rootless user CANNOT install it
```

The conversion is one-way, so rootless is the superset and the
distribution format. Keep both: install the roothide one locally, keep
`packages/..._iphoneos-arm64.deb` to share.

And state the limit honestly: *"Distribute the rootless build. I could
only test it on this device."* Do not hand the user an untested-elsewhere
package as if it were verified.

### 1.8 Building on the Mac (when caps 0x80 is needed)

The one thing the device cannot do is emit `caps 0x80`. A Mac can, and
the whole chain was measured end to end (13 Sep 2026, ShivLockLabel):

```
Mac + roothide fork, ARCHS = arm64e, THEOS_PACKAGE_SCHEME=roothide
  → arm64e deb whose dylib is caps 0x80   (device build gives 0x00)
  → scp to the device
  → dpkg -i            (roothide-native, no patch.sh)
  → loaded in SpringBoard, label showed
```

The Mac's theos is a separate install with its own kind — **measure it,
do not infer it from the folder name.** A directory literally named
`theos-roothide` turned out to be standard theos (git remote
`theos/theos`, `vendor/mod/` only `rootless`), so it could not build the
roothide scheme at all.

```
ls <mac-theos>/vendor/mod/        roothide present = fork
grep -m1 url <mac-theos>/.git/config
ls <mac-theos>/sdks/              SDKs are a separate copy from the device's
```

If the Mac lacks the fork: either install it there the same way (clone
into its own path, copy SDKs from the existing theos), or build the
ROOTLESS scheme on the Mac and convert on the device with patch.sh.

Only send a project to the Mac when you need caps 0x80 (a block handed
to the system) — on-device is faster for everything else. Ask before the
first command on the user's computer.

---

## 2. INSTALLING THE ENVIRONMENT (when something is missing)

theos is NOT a package — it is not in any repo. Only
`theos-dependencies` is (Procursus, and RootHide's own Procursus fork).
On RootHide, prefer RootHide's repo.

You may install things yourself, but the device is the user's: show the
exact command, say what it does, and give the rollback, then ask.

| Action | Risk | Gate |
|---|---|---|
| `apt install <named pkg>` | reversible, tracked by apt | ask, then do. **On RootHide the repo is UNSIGNED**: plain `apt-get install -y <pkg>` always dies with `E: There were unauthenticated packages and -y was used without --allow-unauthenticated`. Add `--allow-unauthenticated` (measured 20 Sep 2026, re.frida.server). Do not go hunting elsewhere - the error is about the signature, not the package |
| `git clone <dir>` | adds a directory only | ask, then do |
| `install-theos` / `install-sdk` | downloads and runs a script | ask, SHOW THE URL |
| `apt upgrade` / `dist-upgrade` | can break the jailbreak | **NEVER** |

Ask like this, not "shall I install theos?":

```
I will run:
    git clone --recursive https://github.com/roothide/theos.git \
      /var/mobile/theos-roothide
What it does: downloads the RootHide fork into its own directory.
It does not touch the existing theos.
To undo: rm -rf /var/mobile/theos-roothide
```

### Ladder

1. **Basics** (if missing): `bash curl sudo coreutils xz-utils`
2. **`theos-dependencies`** — pulls clang, ldid, make, perl, odcctools
3. **theos itself:**
   - RootHide: `git clone --recursive https://github.com/roothide/theos.git $THEOS`
   - rootless/standard: `bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"`
   - `install-theos` respects a preset `$THEOS` and does not delete an
     existing install (it runs update-theos instead).
   - **Where:** fork already installed → install nothing. A standard
     theos exists → put the fork in its OWN path and leave the other
     alone. Nothing installed → install the fork directly, one install
     is enough (the fork does rootless too).
   - Do NOT repoint the global `$THEOS` at the fork; pass
     `make THEOS=<fork>` instead.
4. **SDK:**
   - `ls <fork>/sdks/` — present? done.
   - else copy: `cp -r /var/mobile/theos/sdks/*.sdk <fork>/sdks/` (fastest, worked here)
   - last resort: `<fork>/bin/install-sdk`
5. **VERIFY — do not say "installed", measure:**
   ```
   ls <fork>/vendor/mod/roothide     # really the fork?
   ls <fork>/sdks/                   # SDK there?
   command -v clang ldid make perl   # tools on PATH?
   ```
   Anything missing = the install is half done; say so.
6. **First real test:** build a tiny tweak. The
   `dm.pl: building package ... in <path>` line must appear. If it does
   not, the environment is not ready.
7. **Tell the user what landed where** — what was installed, to which
   path, and how to undo it.

---

## 3. DISCOVERY — find the class to hook

| Need | Tool |
|---|---|
| classes of a RUNNING app | `shiv-oku <bundle-id> <regex> [secs]` |
| what is ON SCREEN in a running app (views, VCs, ids) | `shiv-ekran <bundle-id> [attempts]` |
| decrypt an App Store binary (offline use) | `shiv-cek <bundle-id>` |
| SYSTEM classes (dyld cache / cache-external) | `shiv-sinif <pattern>` / `--tara` |
| METHODS of one cache-external binary | `shiv-sinif --metod <path>` |

- `shiv-oku` spawns the app once, caches the full class list (~10 min),
  then re-filters the cache — refine the regex freely, it will not
  relaunch. `--taze` forces a fresh launch. The regex is
  CASE-SENSITIVE; `^HP`, `^EnabizPlus\.` etc. give the app's own prefix.
- Do NOT static-read `shiv-cek` output with `shiv-sinif --tara` —
  `--tara` scans cache-external SYSTEM dirs, not your decrypted file.
- **Never** fall back to `nm -gU`: it under-counts badly (6 vs 410).
- Bundle id: `plutil -key CFBundleIdentifier <App>.app/Info.plist`.
  It reads BINARY plists too (measured 21 Sep 2026:
  `/rootfs/Applications/MobileSafari.app/Info.plist` ->
  `com.apple.mobilesafari`, rc=0). This device's plutil is NOT Apple's:
  `plutil -extract KEY raw FILE` treats every argument as a file name
  ("File not found at path CFBundleIdentifier") and prints nothing
  useful. `grep -A1 CFBundleIdentifier` works only on XML plists: the
  App Store apps under `/var/containers` matched, the system apps under
  `/rootfs/Applications` (binary) returned nothing.
- Bundle ids of RUNNING apps, no plist needed:
  `launchctl list | grep UIKitApplication`.
- System apps live under `/rootfs/Applications` (RootHide). A name under
  `/System/Library/AppPlaceholders` means the app is DELETED from this
  device (measured: Weather, Find My, Health, News, Stocks, Shortcuts) —
  do not search further for it.
- App-embedded SDK frameworks (`<App>.app/Frameworks/NAME.framework`)
  are usually already unencrypted — scan them directly.

**EXISTING IS NOT CALLABLE — measured, cost a Safe Mode.**
These tools answer "does the symbol exist", never "may I call it".
`setBacklightState:` was in the cache and still put the device into
Safe Mode. So:

- Static lookup is the FIRST filter, not the verdict.
- A selector that exists may still be unavailable in THIS process, may
  require an entitlement, or may be a PAC-protected API (section 1.6).
- Confirm at runtime before relying on it: `respondsToSelector:` /
  `objc_getClass` on the live process, or a marker-file probe
  (section 5). Do not ship a hook whose only evidence is a name in a
  class dump.

### What is on screen right now — `shiv-ekran`

`shiv-oku` answers "which classes exist in this app". `shiv-ekran`
answers "which views are on screen right now, which class draws each
one, and which view controller owns it" — the question to answer
BEFORE you pick a hook target.

```
shiv-ekran [--izle secs] [--donme] <bundle-id> [attempts]   # default 15 attempts
```

- It ATTACHES to the running app. Nothing is relaunched, so you get the
  screen the user navigated to. Nothing is hooked or changed; repeat it
  after every navigation step.
- The app must be running AND FRONTMOST. A backgrounded app is
  suspended and attach fails with `Timeout` or `Unexpected error while
  probing dyld of target process`. The tool waits 3 s
  (`SHIV_EKRAN_BEKLE=<secs>` changes it), then retries. Your terminal is
  in front while the command runs, so tell the user first: "open
  <app>, go to the screen, stay there until the phone vibrates, then
  come back".
- The summary is printed and saved to `/var/mobile/tw/ekran-<bundle-id>.txt`:
  - `== VC AGACI` — the VC tree. Non-appeared VCs show their state,
    e.g. `(disappeared)`. `[gorunur]` = this VC instance (matched by
    address, not class name) owns a visible view; pick hook targets
    from these. `[uzak surec]` = a `_UIRemoteViewController`: its
    content is drawn by another process and is NOT in the dump (the
    document browser of Numbers/Pages/Keynote gave 13 lines).
  - `== GORUNUR GORUNUMLER` — one line per visible view that carries
    information: `Class x,y WxH "text" id=<accessibilityIdentifier>
    ax="<accessibilityLabel>" <- OwningVC`. Coordinates are window
    points.
  - Skipped: hidden views (isHidden / alpha < 0.01), zero-size views,
    plain containers (UIView, UIImageView, UIStackView, …) with no
    text, id or VC — their children are still walked. A child label
    that repeats its cell's text is dropped.
- Raw dump (`_printHierarchy` + `recursiveDescription`):
  `/var/mobile/tw/ekran-<bundle-id>-ham.txt`, 43–49 KB for Settings.
  `grep` it; never `cat` it into your context.
- Measured 21 Sep 2026 (iPhone 15 Pro, iOS 17.0.3, RootHide), all on
  the first attempt, 12–15 s per run including the 3 s wait: Settings
  root 53 lines / 2.9 KB, About page 64 lines / 3.5 KB, YouTube 67 lines / 4.3 KB, Keynote 37 lines,
  Apple Support (SwiftUI) 67 lines, Instagram 128 lines / 10 KB (raw
  313 KB). No run hit the 400-line cap.
- Opening the app yourself works: `uiopen --bundleid <bid> && sleep 2
  && shiv-ekran <bid>` brings it to the front, no user action needed
  (measured, 7 apps). Only the app's launch screen is reachable that
  way; deeper screens need the user to navigate. The bundle ids of
  RUNNING apps: `launchctl list | grep UIKitApplication`.
  Turkish text arrives intact: the summary is read from a UTF-8 file,
  because shivfrida's console turns non-ASCII characters into `?`.
- Reading it:
  - `id=` is the most stable handle and survives localisation; text
    does not. Settings cells carry `WIFI`, `AIRPLANE_MODE`,
    `Bluetooth`…; YouTube's tab bar carries
    `id.ui.pivotbar.FEshorts.button`.
  - Texture (AsyncDisplayKit) apps such as YouTube draw with
    `_ASDisplayView`; their text is only in `ax=`. The logic lives in
    the node or the owning VC, not in `_ASDisplayView` — search those
    with `shiv-oku`.
  - SwiftUI (measured: Apple Support, `com.apple.supportapp`): the
    screen is `SwiftUI._UIHostingView<Module.SomeView>` with
    `SwiftUI._UIGraphicsView` children; text arrives as UILabel text
    or `ax=`, `id=` is rare. Mangled Swift names are shortened in the
    summary (`_TtGC7SwiftUI19UIHostingControllerV7Lithgow9LobbyView_`
    -> `SwiftUI.UIHostingController<Lithgow.LobbyView>`); the full name
    is in the raw dump — `grep` it there when you need the exact
    runtime name. SwiftUI views are structs, not classes: hook the
    owning UIKit VC / hosting controller or the model underneath, not
    the view.
  - A class in the summary EXISTS in the live process (it was read from
    a live object). Instagram's `IGRootViewController` was in the
    summary, yet `shiv-oku ... '^IGRootViewController' 5` found 0. The
    likely cause is timing: shiv-oku spawns fresh and lists classes after
    N seconds, before lazily loaded code is in (not yet confirmed). Retry
    with `shiv-oku --taze <bid> '<regex>' 15`; do not conclude the name
    is wrong.
- Deeper screens: `shiv-ekran --izle <secs> <bundle-id>` (record mode).
  It stays attached for <secs>; every time the VC tree changes and then
  holds still (a push, a tab switch, a modal) it writes a numbered dump
  and the phone vibrates. Scrolling alone does not create a new record.
  Files: `/var/mobile/tw/ekran-<bid>-01.txt`, `-02.txt`, … (+ `-NN-ham.txt`);
  the tool prints one line per page with its deepest visible VC. Use it
  when the target is not on the launch screen: tell the user what to
  open, in order, and to wait for each vibration.
- When it finishes (success or not) the tool brings back the terminal it
  runs in, found by walking up the process chain to the first
  `UIKitApplication` process (measured: NewTerm = `ws.hbang.Terminal`,
  `uiopen` brought it back). `--donme` disables this;
  `SHIV_TERMINAL=<bundle-id>` overrides it. Do NOT guess the terminal
  from `/Applications`: several terminals can be installed
  (`com.apple.Terminal`, MTerminal, iGhostVT…) and opening the wrong one
  looks like success.
- Same frida-server requirement as `shiv-oku` (16.x, `shiv-frida-kur`).
- When the user asks to read / look at the screen: run `shiv-ekran`
  FIRST and answer FROM THE DUMP - the visible VCs, the app's own class
  prefix, the `id=` handles, what each one is - before proposing
  anything. `shiv-oku` and `shiv-cek` RELAUNCH the app (spawn) and throw
  away the screen the user navigated to: run them only after the dump,
  and only if still needed. An encrypted app needs NO decryption step
  for this: `shiv-ekran` and `shiv-oku` read the running process, where
  the code is already decrypted. `shiv-cek` is only for an offline copy
  (Mac class-dump, shipping an IPA) - never a first step, and never run
  `nm` on its output (seen on the device, 21 Sep 2026: a "read YouTube
  from the screen" request went decrypt -> `nm -gU` -> a tweak menu
  with no summary of the dump).
- A long tool output can be cut at shiv's tool-output limit - that is
  not the dump. Before saying something is missing, read the whole
  summary from `/var/mobile/tw/ekran-<bid>.txt` (record mode:
  `ekran-<bid>-NN.txt`); seen on the device: "Subscriptions / You
  (truncated in dump)" was in the file. In record mode the page name in
  the list is the deepest VISIBLE VC; helpers whose name has a part
  starting with `_` (SwiftUI's `_ViewSizeReader`, etc.) are skipped
  (measured: Settings > Legal came out as
  `Settings._ViewSizeReader.Reader` before this).

### Custom frida agents

```
write the agent to a WRITABLE dir first (/var/mobile/tw/agent.js)
cd /var/mobile/tw && <shivfrida> spawn <bundle-id> agent.js [secs]
```

You must `cd` into the agent's directory and pass a RELATIVE name — an
absolute agent path is rejected ("agent okunamadi"). The shivfrida
directory is root-owned, so you cannot create files there.

Agent walls: the main executable is not `enumerateModules()[0]` — match
`NSBundle.mainBundle().executablePath()`. A spawned app is sandboxed;
write output to its own `NSTemporaryDirectory()` and read it from the
shell under `/rootfs/.../Containers/Data/Application/<UUID>/tmp/`. Poll
with `setInterval` until `ObjC.available` and the module is loaded — a
fixed `setTimeout` fires too early and produces nothing.

---

## 4. HOOK PATTERNS

- **Hook only a class's OWN method.** Swizzling an inherited method
  rewrites the superclass and can black-screen the app.
- **Firebase/Google-wrapped AppDelegate:** `%hook <App>.AppDelegate` on
  delegate methods never fires — at runtime the class is re-wrapped
  (`GUL_<App>.AppDelegate-...`). Instead run from `%ctor` and observe
  `UIApplicationDidFinishLaunchingNotification`; that fires regardless
  of the wrapping. (Measured: e-Nabız, Yandex Navi.)
- **Bridged Swift class** (`%hook Module.Class`, e.g.
  `Excel.XLApplicationSceneDelegate`): logos warns and Theos treats the
  warning as an error, so the build fails. Add to the Makefile:
  ```
  ADDITIONAL_LOGOSFLAGS = -c warnings=default
  ```
  Heed the warning though — a bridged-Swift hook may not catch every
  invocation. If it is flaky, hook a stable scene/lifecycle selector.
- **Presenting UI:** walk `keyWindow.rootViewController` down through
  `presentedViewController` to the top VC, and present inside a
  `dispatch_after` (~0.5 s). Presenting straight inside
  `scene:willConnectToSession:` or didFinishLaunching — before the
  window hierarchy exists — silently shows nothing.
- **Removing ads/promos in a modern SwiftUI app:** hiding the VIEW is
  the beginner trap (SwiftUI keeps the layout space → a gap; and a
  shared view class breaks other UI). The real fix is the DATA/NETWORK
  layer: filter the promo out of the API response. A compiled swizzle of
  a Swift/Alamofire delegate is fragile; frida-runtime or a proxy is the
  practical path.
- Logos/`%hook` links libsubstrate; on RootHide the
  `@loader_path/.jbroot/...` resolution is handled by the fork — nothing
  extra to do.

---

## 4b. SETTINGS PAGE (prefs) — failures are SILENT

Nothing errors. The build passes, the tweak loads, the page is empty or
the toggle does not save. This is the quietest area in tweak dev.
Diagnose from measurement, never guess:

```
page missing entirely   is the PreferenceLoader plist in the deb?
                        dpkg-deb -c <deb> | grep PreferenceLoader
page empty              is Root.plist in the deb?
                        dpkg-deb -c <deb> | grep Root.plist
choice not saved        which file is it writing?
                        find / -name '<pkg>.plist' 2>/dev/null
tweak does not see it   TWO files? jbroot vs rootfs (see §6)
row not tappable        selector must match EXACTLY — "x" != "x:"
setting applies LATE    cfprefsd buffers writes (see below)
```

**A cell appearing proves NOTHING about its action working.** And a page
opening proves nothing about its specifiers loading. Prove each layer.

### The recipe that worked (measured on device, enabled 0→1)

Reference: ActionButtonFixPrefs (`ABFRootListController.m`), battle-tested.

1. **arm64e is required.** Preferences.app is arm64e. A code-less bundle
   fails with "could not determine executable location" — a prefs
   bundle always needs a binary, even a stub. An arm64 bundle is
   rejected: "incompatible architecture, need arm64e". On device,
   `clang -arch arm64e` gives caps 0x00, which is **fine for prefs** —
   prefs is selector + ivar only, it does not hand blocks to the system
   (see §1.6). Mac/caps 0x80 is not needed here.

2. **Empty page = wrong ivar.** `PSListController` reads its own
   `_specifiers` ivar. Writing to your own ivar (`_shivSpecifiers`) or
   to a re-declared `_specifiers` (wrong offset unless linked against
   Preferences) gives an empty page.

3. **Two routes:**

   - **A — compiled subclass** + `MyPrefs_PRIVATE_FRAMEWORKS = Preferences`
     + `loadSpecifiersFromPlistName:@"Root"`. Simplest. Do NOT re-declare
     `_specifiers`; let it come from the linked header.
   - **B — runtime class** via `objc_allocateClassPair(PSListController,…)`.
     Read `_specifiers` through `class_getInstanceVariable` +
     `object_getIvar/setIvar`, parse `Root.plist` by hand
     (`NSPropertyListSerialization`, `"specifiers"` key,
     `preferenceSpecifierNamed:target:set:get:detail:cell:edit:`, cell
     type via `[PSTableCell cellTypeFromString:]` — do NOT hard-code the
     number (`PSStaticTextCell` was 7 here, but numbers differ between
     versions). A recorded mistake: swapping `PSStaticTextCell` for
     `PSLinkCell` was suggested once and was WRONG — `PSLinkCell` pushes
     a sub-page. For a switch:
     set = `setPreferenceValue:specifier:`, get = `readPreferenceValue:`.

   Route B becomes MANDATORY for a runtime class, because its
   `bundleForClass:` returns nil, so `loadSpecifiersFromPlistName` cannot
   find `Root.plist`. We used B and it worked. (A crashed Settings in
   one build via a static ObjC class definition — §4.5 territory — but
   not on every install.)

4. **The `-O0` trap — and its permanent fix.** Tapping a row did not
   save the choice: it worked in debug, failed in release. The cause was
   not the optimiser finding a bug — the debug build was HIDING one. The
   trace function's `fopen`/`fprintf` acted as a compiler barrier;
   turning it into a no-op for release let `-O2` reorder the surrounding
   `object_setIvar` and `__bridge` cast, and the specifier's action ivar
   ended up wrong. `-O0` was the STOPGAP. The real fix (ABF 2.2.1, `-O0`
   removed, 86112 → 69344 bytes) is to write the SEL as a RAW POINTER
   instead of through `__bridge id`:

   ```objc
   *(SEL *)((char *)(__bridge void *)spec + offset) =
       sel_registerName(name);
   ```

   General lesson, beyond prefs: **when something works in debug and
   breaks in release, look for a debug side effect (logging, I/O) that
   was acting as a barrier — do not start by blaming the optimiser.**

5. **File names line up exactly.** `entry.plist`'s `bundle` name matches
   the `.bundle` folder byte-for-byte. `entry` →
   `/Library/PreferenceLoader/Preferences/`, bundle →
   `/Library/PreferenceBundles/`.

6. **Sandboxed app reading the pref:** `NSUserDefaults(suiteName:)` is
   redirected inside a sandbox. ABF reads the plist by hand, trying
   multiple paths (`/var/mobile/…`, `/var/jb/var/mobile/…`,
   `/var/containers/…/.jbroot-*/var/mobile/…`). The Settings side writes
   with the standard set/get (`/var/mobile/Library/Preferences/<domain>.plist`).

7. **A prefs bundle is subject to §1.6 caps rules.** Preferences.app is
   arm64e + PAC, so an `@""` literal or a block handed to the system in
   the prefs binary hits the SAME wall (Safe Mode). ActionButtonFix's
   prefs passed because its `__cfstring` was 0. Check it like any other
   arm64e system target: `otool -l <prefs-binary> | grep -c __cfstring`.

### Two writers on one file — a silent data-loss trap

If switches use CFPreferences while other rows use your own writer, they
write the SAME file by different paths (measured):

- A writer that rebuilds the file from scratch DELETES keys it does not
  know about. Add a switch without teaching the other writer about it,
  and the setting silently disappears the next time an action changes.
- **cfprefsd BUFFERS.** Measured: 6 seconds between the tap and the file
  changing on disk. A tweak reading from disk sees the OLD value for
  that whole window. Fix, inside the Settings process (NOT SpringBoard):
  `CFPreferencesAppSynchronize(CFSTR("<domain>"));`
  The "no CFPreferences on device" concern is about SpringBoard; the
  prefs bundle runs inside Settings, where CFPreferences is already in
  use.
- Which writer touched the file, from the file's own layout:
  `CFPreferences` dedups (two `false` share one object: refs
  `06 07 08 08 0a`); a hand writer does not (`06 07 08 09 0a`).

### Hand-built binary plist — two silent limits

- Keys of 16+ characters need the `0x5F` extended-length form. A
  17-char key written as `0x51` reads back as one character.
  Verify: `xxd <plist> | grep 5f`
- `offSize = 1` in the trailer caps the file at 256 BYTES; past that,
  offsets wrap silently and the plist is corrupt. Measured: 3 keys = 108
  bytes, 5 keys ≈ 156, ~7 keys hits the ceiling. Guard the write:
  `if (pos > 250) { trace("WRITE_ABORT_SIZE"); return; }` — refusing to
  write beats writing garbage that takes the working keys down with it.

### Diagnosing an empty page

Put a log in the specifiers method:

```
never called   → entry.plist or the class is wrong
called, count 0 → Root.plist or the bundle is wrong
count > 0, still empty → the cell type
```

Try the standard route first (PreferenceLoader + Root.plist +
`NSUserDefaults(suiteName:)`); only hand-build specifiers when that is
MEASURED to fail.

### Filter.plist — where the dylib gets injected (applies to any tweak)

```
Bundles     → com.apple.springboard     SpringBoard
Bundles     → com.burbn.instagram       an app
Executables → mediaserverd              a daemon
```

A wrong filter means the tweak loads nowhere and there is NO error.
Theos generates it from `<NAME>_FILTER`, or you write it into
`layout/.../TweakInject/<NAME>.plist`. Verify it reached the package:
`dpkg-deb -c <deb> | grep '\.plist'`

## 5. VERIFY WITHOUT RE-PLOWING THE FIELD

Ranked, cheapest first:

1. **Marker file** — have the hook write a small file into the app's own
   `NSTemporaryDirectory()` when it fires, then read it ONCE from the
   shell. This machine-proves the hook ran; no screen needed.
2. **Loaded?** — one attach that finds your dylib among the loaded
   modules proves the tweak LOADED.
3. **Purely visual effect you cannot see** — ask the user ONCE. Do not
   keep re-attaching.

Facts that look like failures but are not:

- A modal alert FREEZES the app (`0% CPU`, frida attach timeout). That
  is the alert SHOWING, not a crash.
- `uiopen <bundle-id>` is a normal launch, so TweakInject loads your
  dylib. `frida spawn` uses its own loader and does NOT load installed
  tweaks — never verify an installed tweak via spawn.
- A SpringBoard tweak needs a respring. Do not respring or
  `killall SpringBoard` yourself — ask the user.

---

## 5b. TRACING — where you can write depends on the target

Six versions were burned on this once, and three hours on another
occasion. Keep the record.

### The `/rootfs` trap — hit FOUR times in this project

A tweak runs inside SpringBoard or an app and writes to the REAL rootfs.
Your ssh session lives in the jbroot namespace. Same path string,
different filesystem.

**`/private` is a second trap inside the first.** Knowing about `/rootfs`
is not enough:

```
/rootfs/var/mobile/x.txt           NOT FOUND
/rootfs/private/var/mobile/x.txt   correct
```

On iOS `/var` is a symlink to `/private/var`. The shell follows it in
some contexts and not when going through `/rootfs`. One trace file cost
hours: `/rootfs` was added, `/private` was left out, the file was
declared missing, and the whole diagnosis was rebuilt on that mistake.

Probe all three, never guess:

```bash
for P in /rootfs/private/var/mobile/FILE \
         /rootfs/var/mobile/FILE \
         /var/mobile/FILE; do
  printf "%-52s " "$P"; [ -f "$P" ] && echo "EXISTS ($(stat -c %s $P) B)" || echo "no"
done
```

**If you cannot find a file, it does not mean the file is not there — it
means you are looking in the wrong namespace.**

### Which channel — disk vs memory

```
disk    survives a respring, read later — first choice in SpringBoard
        write to the ABSOLUTE physical path /rootfs/private/var/mobile/…
memory  volatile, gone with the process — first choice in a sandboxed
        app; skips the filesystem and the namespace question entirely
```

Disk trace: `fopen("/var/mobile/tw_trace.txt","a")`. **A file EXISTING
does not prove data was WRITTEN** — `fopen` creates it while the write
goes elsewhere, and `fprintf` returns no error you checked. Look at the
SIZE, and read the return value: `int n = fprintf(...); int r = fflush(...);`
— `n<0` or `r!=0` means it failed.

Memory trace (for sandboxed apps): a non-static exported buffer read
with frida `Memory.readCString`. If the symbol is invisible:
`<Tweak>_LDFLAGS = -Wl,-exported_symbol,_tw_buf`.

Get ONE channel working before adding a second.

### Staged labels — what makes a trace useful

Put a label between every step; which one got written gives the death
point to single-statement precision.

```c
tw_trace("1. ctor entered");
NSString *t = [NSString stringWithFormat:@"%d", 7];
tw_trace("2. NSString built");   // missing → the line above killed it
```

"The camera crashes" became "COMPLETION_CREATED written, EXECUTE_AFTER
not". That is the whole value.

**Confirm the trace is actually compiled in** before concluding anything:
`strings $DYLIB | grep -c 'tw_trace.txt'` (>0 on, 0 off). A trace
compiled out and a file read from the wrong namespace look IDENTICAL
from outside — both happened here, stacked.

### Often you need no trace at all

frida watches the same methods from OUTSIDE — whether your hook fired,
whether a value changed, whether something ran twice. No code change, no
build, no install. Try this BEFORE adding a trace. A tweak-side trace is
only for BRANCH DECISIONS: which path, what value.

### NSLog through frida — the variadic trap

Frida reads only the format argument; variadic args are lost.

```objc
NSLog(@"TAG=%d", v);    // prints "TAG=%d" — value LOST
NSLog(@"%@", [NSString stringWithFormat:@"TAG=%d", v]);   // works
```

**If a diagnostic line cannot itself be read, every conclusion drawn
from it is baseless. Prove the channel first.**

### "Exists" is not "callable" — measure before you call

A method being in a class list does not mean calling it is safe.
`setBacklightState:` was in the cache, its encoding read fine, and
calling it Safe-Moded the device. Before using a new API, measure it
WITHOUT calling — existence + type encoding + a sanity line:

```c
Method m = class_getInstanceMethod(cls, sel_registerName(name));
snprintf(b, sizeof b, "M:%s:%s:%s", name, m?"YES":"NO",
         m?method_getTypeEncoding(m):"-");
```

Never call the found selector, never call a `dlsym` pointer, never
`class_copyMethodList` (it crashes here). Add a SANITY line for a
known-good class — if it is missing, the block never ran and the whole
measurement is void. In the encoding, **`@?` means a BLOCK parameter →
the §1.6 caps wall.**

## 6. NAMESPACE

- **node** sees logical paths (`/System`); the **shell** sees the same
  content under `/rootfs/System`. A system process (SpringBoard) writes
  `/var/mobile/x`; from the shell that file is at `/rootfs/var/mobile/x`.
  When a file you expect is "missing", look under `/rootfs` before
  concluding a tweak did not load. `/rootfs` is RootHide-only.
- `/var/jb` → `/` on RootHide (a compat symlink for rootless tweaks);
  on rootless it is the real jailbreak root.
- `/Library/MobileSubstrate/DynamicLibraries` is a **symlink** to
  `/usr/lib/TweakInject` — the same directory. A roothide-native deb
  installs into the MobileSubstrate path and still loads. Do not treat
  them as two places.
- jbroot multi-mount: measured on this device and NOT confirmed
  (`mount | grep jbroot` empty, one `.jbroot-*` dir). If paths behave
  strangely, measure again rather than assuming.
- `<roothide.h>` + `jbroot()` exists for tweaks that need to reach
  jailbreak files, but most tweaks do not. Globbing
  `/var/containers/Bundle/Application/.jbroot-*/...` also works.

---

## 7. KNOWN-GOOD REFERENCE TWEAKS

Sources and reports live in the user's `shiv-tweaks/` archive on the
desktop:

| Tweak | What it proves |
|---|---|
| EnabizShiv | app tweak; Firebase-wrapped delegate → `%ctor` + notification |
| ShivYTAlert | the rootless → patch.sh → dpkg -i flow, and later roothide-native |
| ExcelShiv | bridged-Swift hook + logos flag |
| YandexNaviShiv | Flutter/Swift hybrid; finding the REAL delegate |
| ShivLockLabel | SpringBoard (arm64e) tweak, both build flows |


## 8. MEASUREMENT — the techniques that paid off

The largest technical gain of the caps round was not the rule; it was
HOW it was measured. These are reusable.

### Reading the architecture — byte 9 AND byte 12, magic first

```
cf fa ed fe 0c 00 00 01 | 00 00 00 00   arm64,  no PAC
cf fa ed fe 0c 00 00 01 | 02 00 00 80   arm64e, NEW ABI (Mac)
cf fa ed fe 0c 00 00 01 | 02 00 00 00   arm64e, OLD ABI (device)
                          ^^        ^^
                    cpusubtype     caps
```

**Byte 12 alone is not enough.** Both `arm64` and `arm64e OLD ABI` show
caps `00`; byte 9 (cpusubtype) separates them. And **check the magic
first** — for a FAT binary byte 12 is not caps at all, it is the low
byte of `CPU_TYPE_ARM64` (0x0100000c) big-endian, always `0c`:

```bash
od -A n -t x1 -N 4 "$f" | tr -d ' '
  cffaedfe   thin  → byte 12 is caps
  cafebabe   FAT   → use lipo -detailed_info instead
```

Measured: all 24 FAT tweaks on one device read `0c` — a misread, not a
value. `file` is unreliable too: it prints "PAC00" for both. Read the
byte.

### Detecting Safe Mode from the shell

`ps` does not exist here. `launchctl` exit codes do:

```
/usr/bin/launchctl list | grep -i springboard
  PID   -9   SIGKILL from sbreload   NORMAL
  PID    0   clean exit              NORMAL
  PID  -10   SIGBUS                  CRASHED
```

No crash log is written and there is no safe-mode marker file. A PID
that CHANGES across a respring proves it restarted; one that STAYS PUT
proves it is not in a crash loop.

### A single-command A/B switch

A controlled experiment needs the variable toggled in one command, with
a guaranteed way back. To measure whether OldABI is what makes a tweak
"work":

```bash
mv /usr/lib/ellekit/OldABI.dylib  /usr/lib/ellekit/OldABI.dylib.off
# respring, test — then:
mv /usr/lib/ellekit/OldABI.dylib.off  /usr/lib/ellekit/OldABI.dylib
```

Renaming beats `dpkg -r`: no deb in the apt cache means reinstall would
need the network. `md5sum` confirms the same file each time. **Download
the deb first if you might remove a package:** `apt download oldabi`.

### Verify the install — and the trap under it

```bash
otool -l /usr/lib/TweakInject/X.dylib | grep -A2 LC_UUID
[ "$BUILT_UUID" = "$INSTALLED_UUID" ] && echo ">>> safe to test" \
                                      || echo ">>> MISMATCH, DO NOT TEST"
```

If `make` failed, the PREVIOUS deb is still in `packages/` and `dpkg -i`
installs it — four tests were wasted on stale debs in one round. Never
say "test it" before the UUIDs match. File size is no substitute (page
alignment hides changes); compare section sizes: `otool -l $D | grep -A4
'sectname __text' | grep size`. `strings` misleads on a stripped binary
— use `nm -u`. A prefs bundle is a SEPARATE binary; verify it too.

### What is missing on the device, and what to use instead

```
ps       → /usr/bin/launchctl list
plutil   → exists, but only `plutil -key KEY FILE` (see §3); no -extract
strings  → misleading on stripped binaries; nm -u
python3  → python3.9
xxd      → od -A d -t x1
fswatch  → md5sum polling
```

An ssh session is a non-login shell, so PATH comes up short:
`export PATH=/usr/bin:/bin:/usr/sbin:/sbin:$PATH`. When copying a source
tree from macOS use `COPYFILE_DISABLE=1`, or `._*` files land in
`Resources/` and Theos packages them. Theos builds with `-Werror` — an
unused variable stops the build.

### Experiment design — three rules

```
1. WRITE THE PREDICTION FIRST. If you do not write "if X, then Y"
   before running, whatever comes out gets fitted to the story.
2. ONE VARIABLE. A test that changed both a literal and a block capture
   was read backwards; two single-variable follow-ups separated them.
   If two things changed, causation CANNOT be assigned.
3. VERIFY THE INSTALL (above). A stale deb tests old code.
```

When an experiment gives a confusing result, do not make it bigger —
REDUCE the number of variables.
