#!/bin/sh

set -u

duration="${1:-900}"
case "$duration" in
    *[!0-9]*|'')
        echo "用法: $0 [采集秒数，默认 900]" >&2
        exit 64
        ;;
esac

output_root="${WLK_OUTPUT_ROOT:-/var/mobile/Library/Logs/WiFiLeaseKeeper}"
log_tool="${WLK_SYSTEM_LOG:-/usr/bin/log}"
timestamp="$(date '+%Y%m%d-%H%M%S')"
session="$output_root/$timestamp"
mkdir -p "$session" || exit 1

sanitize() {
    sed -E \
        -e 's/([0-9]{1,3}\.[0-9]{1,3})\.[0-9]{1,3}\.[0-9]{1,3}/\1.x.x/g' \
        -e 's/([[:xdigit:]]{2}:[[:xdigit:]]{2}):[[:xdigit:]]{2}:[[:xdigit:]]{2}:[[:xdigit:]]{2}:[[:xdigit:]]{2}/\1:xx:xx:xx:xx/g'
}

snapshot() {
    phase="$1"
    {
        echo "phase=$phase"
        date '+time=%Y-%m-%d %H:%M:%S %z'
        if command -v scutil >/dev/null 2>&1; then
            scutil --nwi 2>&1
        fi
        if command -v ifconfig >/dev/null 2>&1; then
            for interface_name in en0 en1 en2 en3; do
                ifconfig "$interface_name" 2>/dev/null || true
            done
        fi
        if command -v netstat >/dev/null 2>&1; then
            netstat -rn -f inet 2>&1
        fi
    } | sanitize > "$session/network-$phase.txt"
}

snapshot before

predicate='subsystem == "com.example.wifileasekeeper" OR process == "wifid" OR process == "powerd" OR (process == "SpringBoard" AND (eventMessage CONTAINS[c] "lock" OR eventMessage CONTAINS[c] "display" OR eventMessage CONTAINS[c] "blank"))'
raw_log="$session/unified.unredacted.tmp"

finalize_log() {
    if [ -f "$raw_log" ]; then
        sanitize < "$raw_log" > "$session/unified.log"
        rm -f "$raw_log"
    fi
}

cleanup() {
    if [ "${stream_pid:-0}" -gt 0 ]; then
        kill "$stream_pid" 2>/dev/null || true
        wait "$stream_pid" 2>/dev/null || true
    fi
    finalize_log
}
trap cleanup EXIT INT TERM HUP

echo "开始同步采集 ${duration} 秒；输出目录：$session"
"$log_tool" stream --style syslog --level debug --predicate "$predicate" \
    > "$raw_log" 2>&1 &
stream_pid=$!
sleep "$duration"
cleanup
stream_pid=0

snapshot after
{
    echo "duration_seconds=$duration"
    echo "addresses=redacted"
    echo "sources=WiFiLeaseKeeper,wifid,powerd,SpringBoard-lock-display"
} > "$session/metadata.txt"

archive="$output_root/WiFiLeaseKeeper-$timestamp.tar.gz"
if command -v tar >/dev/null 2>&1 && tar -czf "$archive" -C "$output_root" "$timestamp"; then
    echo "采集完成：$archive"
else
    echo "采集完成：$session"
fi
