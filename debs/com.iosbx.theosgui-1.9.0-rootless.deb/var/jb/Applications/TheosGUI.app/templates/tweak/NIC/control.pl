my $default_kill = "SpringBoard";

NIC->variable("KILL_RULE") = "";

my $kill_apps = NIC->prompt("KILL_APPS", "安装后要终止的应用程序列表", {default => $default_kill});
if($kill_apps ne "-") {
	NIC->variable("KILL_RULE") = "INSTALL_TARGET_PROCESSES = ".$kill_apps."\n";
}
