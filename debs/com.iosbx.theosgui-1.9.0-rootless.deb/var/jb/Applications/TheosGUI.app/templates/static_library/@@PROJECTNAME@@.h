// Public header for @@PROJECTNAME@@.
// Add declarations for the functions and classes exported by this library.
