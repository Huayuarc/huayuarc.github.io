// Static library implementation.
// Add public functions or Objective-C classes here.
