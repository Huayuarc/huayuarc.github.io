# Corresponding source: com.fluoxetine.luros.agent-tools.assembler 1.0.0

The `luros-assembler` executable in this package contains Keystone, which
is licensed under the GNU General Public License version 2 only (`COPYING`
beside this file; LLVM-derived parts also under `LLVM-LICENSE.TXT`). You may
copy, modify and redistribute it under that license. Luros's own code in it
is MIT (`../Luros/LICENSE`).

The complete corresponding source of this executable, with the scripts used
to build and package it, is:

- `com.fluoxetine.luros.agent-tools.assembler_1.0.0_source.tar.xz` (SHA-256 `5a686092683a259e36b2f3994059855e4ac26d1c16f05d1e81114dcfba93a6b8`), published beside this
  package wherever this package is published;
- and, equivalently, these public repositories at these revisions:
  - Luros, https://github.com/1103945342/Luros at commit `235c2d691700f80c499a9e4dd3de15278fa25830`:
    `Packages/LurosToolHost` and `Extensions/AgentTools/Disassembler`;
  - libkeystone-spm (Keystone as a Swift package),
    https://github.com/Lakr233/libkeystone-spm at commit `3ff184008e1ba49577b944579cd32d32c78451b5`.

To rebuild: install Xcode and run
`Extensions/AgentTools/Disassembler/Scripts/build-agent-tools.sh` in an
Luros checkout. The archive holds that tree under `Luros/`, and the two
Swift packages it depends on under `Dependencies/` (libkeystone-spm, and
libcapstone-spm, which the same package graph names); to build from the
archive without the network, first run, in
`Luros/Extensions/AgentTools/Disassembler`,
`swift package edit libkeystone-spm --path ../../../../Dependencies/libkeystone-spm`
and the same for libcapstone-spm.
