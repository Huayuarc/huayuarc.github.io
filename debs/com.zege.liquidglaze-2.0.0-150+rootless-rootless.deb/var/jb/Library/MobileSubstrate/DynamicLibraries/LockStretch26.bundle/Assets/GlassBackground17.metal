// =============================================================================
// 泽哥有道理（com.zegeyoudaoli）收编：时钟玻璃 shader，收编自 Liquidify GlassBackground17.metal
// 以下为逐字节原文，未做任何阉割。
// =============================================================================

#include <metal_stdlib>
using namespace metal;
// Source reconstruction of the white-clock background branch in 23C54
// glass_background_lpf AIR. The recovered native uniform offsets are retained.
// This is compiled for the running OS, not a retargeted iOS 26 binary.
struct Out {float4 position [[position]];float2 texcoord0;float2 texcoord1;};
vertex Out ls_vertex(uint i [[vertex_id]],constant float4 &r [[buffer(0)]],constant float4 &mapping [[buffer(1)]]) {
 const float2 p[4]={float2(-1,1),float2(1,1),float2(-1,-1),float2(1,-1)};
 const float2 uv[4]={float2(0,0),float2(1,0),float2(0,1),float2(1,1)};
 Out o;o.position=float4(p[i],0,1);o.texcoord0=r.xy+uv[i]*r.zw;o.texcoord1=mapping.xy+uv[i]*mapping.zw;return o;
}
float spherical(float d,float invHeight) {
 float t=saturate(-d*invHeight);return 1-saturate(sqrt(t*(2-t)));
}
float interval(float d,float a,float b) {
 // Equal stops represent a step, rather than an undefined 0/0.
 return a==b ? float(d>=b):saturate((d-a)/(b-a));
}
float blurLevel(float radius) {return max(0.0f,log2(radius<2 ? 1+radius*.5f:radius));}
float3 colorMatrix(float3 c,constant float *u,uint offset) {
 constant half *m=reinterpret_cast<constant half *>(u+offset);
 return float3(dot(c,float3(m[0],m[1],m[2]))+float(m[3]),
               dot(c,float3(m[4],m[5],m[6]))+float(m[7]),
               dot(c,float3(m[8],m[9],m[10]))+float(m[11]));
}
float4 ls_field(texture2d<float> sdf,float2 uv,float2 inverseScale){
 constexpr sampler samplerField(coord::normalized,address::clamp_to_edge,filter::linear);
 float4 field=sdf.sample(samplerField,uv);float2 gradient=field.gb*inverseScale;float magnitude=length(gradient);
 if(magnitude>.0001f){field.r/=magnitude;field.gb=gradient/magnitude;}return field;
}
float4 ls_background(Out in,texture2d<float> source,texture2d<float> sdf,constant float *u,float2 inverseScale) {
 constexpr sampler fieldSampler(coord::normalized,address::clamp_to_edge,filter::linear);
 constexpr sampler backdropSampler(coord::normalized,address::clamp_to_edge,filter::linear,mip_filter::linear);
 float4 field=ls_field(sdf,in.texcoord1,inverseScale);float d=field.r;
 float coverage=saturate(.5f-d/max(fwidth(d),.0001f))*field.a;
 if(coverage<=0)return float4(0);
 float2 displacement=float2(dot(field.gb,float2(u[0],u[1])),dot(field.gb,float2(u[2],u[3])));
 float inner=u[4]*spherical(d,u[5]);
 float3 weights=float3(interval(d+inner,u[44],u[45]),interval(d+inner,u[45],u[46]),interval(d+inner,u[46],u[47]));
 float radius=(u[40]-dot(weights,float3(u[41],u[42],u[43])))*u[10];
 float4 sample=source.sample(backdropSampler,in.texcoord0+inner*displacement,level(blurLevel(radius)));
 float3 color=sample.rgb/max(sample.a,.000001f);
 if(u[51]>0)color=mix(color,colorMatrix(color,u,20),u[51]);
 // Native edge bleed uses a separate, more distant backdrop sample and
 // fourth-power luminance weighting (the captured white recipe lightens).
 float bleed=u[12]*spherical(d,u[13]);
 float4 edge=source.sample(backdropSampler,in.texcoord0+bleed*displacement,level(blurLevel(u[11])));
 float3 edgeColor=colorMatrix(edge.rgb/max(edge.a,.000001f),u,26);
 float luminance=saturate(dot(color,float3(.2125f,.7154f,.0721f)));
 float amount=pow(u[52]*luminance+u[53],4.0f)*pow(interval(d,u[48],u[49]),2.0f)*u[50];
 color=mix(color,edgeColor,amount);
 // White-clock recipes disable the outer refraction and shadow branches.
 // Keep the recovered holding tone and component clamp for their active path.
 float tone=1-interval(d,u[58],u[59]);
 color=mix(color,color*u[62],tone*u[57]);
 if(u[60]>0)color=clamp(color,float3(-.75f),float3(u[60]));
 return float4(color*coverage,coverage);
}

fragment float4 ls_glass_background(Out in [[stage_in]],texture2d<float> source [[texture(3)]],texture2d<float> sdf [[texture(4)]],constant float *u [[buffer(1)]],constant float2 &inverseScale [[buffer(8)]]) {return ls_background(in,source,sdf,u,inverseScale);}
float3 matrix45(float3 color,constant float *m){float4 c=float4(color,1);return float3(dot(c,float4(m[0],m[1],m[2],m[4])),dot(c,float4(m[5],m[6],m[7],m[9])),dot(c,float4(m[10],m[11],m[12],m[14])));}
// QuartzCore 23C54 UberShader::sdf_key_fill_highlight (function 66).
float ls_highlight(float distance,float2 normal,float width,float height,float angle,float spread){
 float u=saturate(distance/height);float fade=mix(float(u<1),1-u,.7f);
 float coverage=saturate(.5f+distance/width)*saturate(.5f+(height-distance)/width);
 float light=saturate((dot(normal,float2(sin(angle),-cos(angle)))-cos(spread))/max(1-cos(spread),.0001f));
 return distance < -5 ? 0:fade*coverage*light; // amount .5 gives bias zero
}
// iOS 17 clamps a layer's unpremultiplied SDR components before compositing.
// Native 26 applies vibrancy after that stage. Re-express alpha against the
// already sampled wallpaper so the same final SDR RGB survives that clamp.
float4 ls_pack_sdr_over(float3 rgb,float alpha,float3 backdrop){
 float3 displayed=saturate(rgb+backdrop*(1-alpha));
 float3 required=saturate((displayed-backdrop)/max(1-backdrop,float3(.00001f)));
 float safeAlpha=max(alpha,max(required.r,max(required.g,required.b)));
 return float4(max(displayed-backdrop*(1-safeAlpha),float3(0)),safeAlpha);
}
fragment float4 ls_glass_material(Out in [[stage_in]],texture2d<float> source [[texture(3)]],texture2d<float> sdf [[texture(4)]],constant float *u [[buffer(1)]],constant float *c [[buffer(7)]],constant float2 &inverseScale [[buffer(8)]]){
 constexpr sampler samplerField(coord::normalized,address::clamp_to_edge,filter::linear);
 float4 field=ls_field(sdf,in.texcoord1,inverseScale);float4 body=ls_background(in,source,sdf,u,inverseScale);
 float lengthGradient=max(length(field.gb),.0001f);
 // Native glyph SDF G/B use the image coordinate direction (Y down).
 float2 normal=field.gb/lengthGradient;
 float distance=-field.r/lengthGradient;
 float width=max(fwidth(distance),.0001f);
 float high=ls_highlight(distance,normal,width,c[40],c[41],c[42])+ls_highlight(distance,normal,width,c[40],c[41]+M_PI_F,c[42]);
 float3 color=matrix45(body.rgb/max(body.a,.0001f),c);
 // render_vibrant_color_matrix (D41FC) filters the white SDF intermediate,
 // then source-over composites it. The clamp uniform is pow(inputClamp,1/gamma),
 // not the raw archive value. Native 23C54 SDR surface gamma is 2.22 (Context constructor at 9D5D8).
 float3 highlightColor=matrix45(float3(1),c+20);
 if(c[44]>0)highlightColor=clamp(highlightColor,float3(-.75f),float3(pow(c[44],1.0f/2.22f)));
 float alpha=saturate(high*c[43]);
 constexpr sampler wallpaperSampler(coord::normalized,address::clamp_to_edge,filter::linear,mip_filter::linear);
 float3 wallpaper=source.sample(wallpaperSampler,in.texcoord0,level(0)).rgb;
 if(c[45]>0)return ls_pack_sdr_over(highlightColor*alpha,alpha,wallpaper);
 float fillAlpha=body.a*saturate(c[18]);
 return ls_pack_sdr_over(highlightColor*alpha+color*fillAlpha*(1-alpha),alpha+fillAlpha*(1-alpha),wallpaper);
}
// Scalar source translation of native variable_blur_downsample_compute's
// 13-tap branch. Half constants are copied verbatim from AIR 076.
kernel void ls_native_downsample(texture2d<float,access::sample> source [[texture(0)]],texture2d<half,access::write> target [[texture(1)]],constant uint &copy [[buffer(0)]],uint2 p [[thread_position_in_grid]]){
 if(p.x>=target.get_width() || p.y>=target.get_height())return;
 constexpr sampler s(coord::normalized,address::clamp_to_edge,filter::linear);
 float2 uv=(float2(p)+.5f)/float2(target.get_width(),target.get_height());
 if(copy){target.write(half4(source.sample(s,uv)),p);return;}
 // Native uniforms contain reciprocals of the destination mip dimensions.
 float2 step=1/float2(target.get_width(),target.get_height());
 half4 axial2=half4(source.sample(s,uv+float2(2,0)*step))+half4(source.sample(s,uv+float2(-2,0)*step))+half4(source.sample(s,uv+float2(0,2)*step))+half4(source.sample(s,uv+float2(0,-2)*step));
 half4 diagonal=half4(source.sample(s,uv+float2(1,1)*step))+half4(source.sample(s,uv+float2(-1,1)*step))+half4(source.sample(s,uv+float2(1,-1)*step))+half4(source.sample(s,uv+float2(-1,-1)*step));
 half4 axial1=half4(source.sample(s,uv+float2(1,0)*step))+half4(source.sample(s,uv+float2(-1,0)*step))+half4(source.sample(s,uv+float2(0,1)*step))+half4(source.sample(s,uv+float2(0,-1)*step));
 half4 value=axial2*as_type<half>(ushort(0x2b36))+diagonal*as_type<half>(ushort(0x2cef))+axial1*as_type<half>(ushort(0x2dc6))+half4(source.sample(s,uv))*as_type<half>(ushort(0x2ec0));target.write(value,p);
}
// Vector-outline SDF: flattening happens once per glyph/layout change, and
// nearest-segment distance and winding are evaluated at pixel centers on GPU.
kernel void ls_outline_distance(device const float4 *segments [[buffer(0)]],constant uint &columns [[buffer(1)]],constant float &scale [[buffer(2)]],constant float4 &bounds [[buffer(3)]],device const uint2 *tileRanges [[buffer(4)]],device const uint *tileEdges [[buffer(5)]],device const uint2 *rowRanges [[buffer(6)]],device const uint *rowEdges [[buffer(7)]],texture2d<float,access::write> target [[texture(0)]],uint2 pixel [[thread_position_in_grid]]){
 if(pixel.x>=target.get_width() || pixel.y>=target.get_height())return;
 float2 p=(float2(pixel)+.5f)/scale;float best=26*26;int winding=0;
 uint2 range=tileRanges[(pixel.y/32)*columns+pixel.x/32];
 for(uint j=0;j<range.y;j++){
  float4 segment=segments[tileEdges[range.x+j]];float2 edge=segment.zw-segment.xy,offset=p-segment.xy;
  float t=saturate(dot(offset,edge)/max(dot(edge,edge),1e-20f));float2 delta=offset-t*edge;best=min(best,dot(delta,delta));
 }
 range=rowRanges[pixel.y];
 for(uint j=0;j<range.y;j++){
  float4 s=segments[rowEdges[range.x+j]];
  if((s.y>p.y)!=(s.w>p.y) && s.x+(p.y-s.y)*(s.z-s.x)/(s.w-s.y)>p.x)winding+=s.w>s.y ? 1:-1;
 }
 target.write(float4((winding ? -1:1)*sqrt(best)),pixel);
}
float ls_gaussian_weight(int k){return exp(-float(k*k)/18.0f);}
kernel void ls_sdf_smooth_horizontal(texture2d<float,access::read> raw [[texture(0)]],texture2d<float,access::write> target [[texture(1)]],uint2 p [[thread_position_in_grid]]){
 if(p.x>=target.get_width() || p.y>=target.get_height())return;
 float sum=0,value=0;for(int k=-9;k<=9;k++){float w=ls_gaussian_weight(k);value+=w*raw.read(uint2(clamp(int(p.x)+k,0,int(raw.get_width())-1),p.y)).r;sum+=w;}target.write(float4(value/sum),p);
}
kernel void ls_sdf_smooth_vertical(texture2d<float,access::read> source [[texture(0)]],texture2d<float,access::write> target [[texture(1)]],uint2 p [[thread_position_in_grid]]){
 if(p.x>=target.get_width() || p.y>=target.get_height())return;
 float value=0,sum=0;for(int k=-9;k<=9;k++){float w=ls_gaussian_weight(k);uint2 q=uint2(p.x,clamp(int(p.y)+k,0,int(source.get_height())-1));value+=w*source.read(q).r;sum+=w;}target.write(float4(value/sum),p);
}
float ls_smoothed_read(texture2d<float,access::read> source,int2 p){return source.read(uint2(clamp(p,int2(0),int2(source.get_width()-1,source.get_height()-1)))).r;}
kernel void ls_sdf_normals(texture2d<float,access::read> raw [[texture(0)]],texture2d<float,access::read> smoothed [[texture(1)]],texture2d<float,access::write> target [[texture(2)]],uint2 p [[thread_position_in_grid]]){
 if(p.x>=target.get_width() || p.y>=target.get_height())return;int2 q=int2(p);
 float2 gradient=float2(ls_smoothed_read(smoothed,q+int2(1,0))-ls_smoothed_read(smoothed,q-int2(1,0)),ls_smoothed_read(smoothed,q+int2(0,1))-ls_smoothed_read(smoothed,q-int2(0,1)));
 float len=length(gradient);gradient=len>.0001f ? gradient/len:float2(0);float distance=raw.read(p).r;
 target.write(float4(distance,gradient,distance<1 ? 1:0),p);
}
