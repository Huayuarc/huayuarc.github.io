# SafariTools 0.2.0 — 固定 12pt 无面板版

基于最新 main `2d9af98e94020af41b4b810f26e32054b6f40311` 的 0.1.7 稳定外观增量修改。包 ID 仍为 `com.yuku.safaritools`，仅一个 `SafariTools.dylib`、一个 constructor，arm64 + arm64e。不是第二个测试插件。

## 使用与关闭

- 本版功能固定启用，没有浮钮、设置面板或开关。**只能通过包管理器卸载本包来关闭**，或卸载后安装保留的旧版本回退。没有自动安装/卸载、postinst、killall 或自动重启。
- 包管理器替换原 SafariTools；保留对 `com.yuku.safarinoinlinecompletion`、`com.yuku.safarifloatingbar`、`com.yuku.safarifloatingbardiagnostics` 的 Conflicts/Replaces。旧 dylib 若仍在当前 Safari 进程内，初始化安全退出；完成包管理操作后由用户正常完全关闭并重新打开 Safari。
- 编辑 lift 固定 **12pt**。旧偏好中的 14/16pt、Enabled、BrowseCard、EditingLift、CompletionInterceptionEnabled 等均不会被本版读取或改变。
- 灰底按原基线上移 12pt；白框保持原 358×45，水平及垂直居中于 390×60 灰底。以原白框 y461、灰底 y449 为例：灰底 y437、白框 y444.5，上下各 7.5pt；白框总位移为 -16.5pt，其中 -4.5pt 是既有居中修正，并非 lift 设置变为16.5。

## 无采集生产边界

生产仅编译 `Production.m Completion.m Appearance.m`。旧 Console、BrowseCapture 和诊断计数/报告代码不再存在于当前生产源码，历史版本仍可由 Git 历史查看。没有计时采集、日志输出、剪贴板、网络请求、报告或偏好读写。不读取地址栏文本、浏览历史、URL 或网页内容。原生补全入口只使用本来传入的按键参数判断换行/marked 语义，不保存输入内容。

补全固定前台启用，但不是绕过安全检查：保留精确 UnifiedField 身份、逐 selector ABI 校验、未知 ABI 透传、IME/marked、paste、manual suggestion、restore、cancel barrier、选区和前后台保护。保留既有功能策略，不声称修复退格/http残留等额外功能。

保留原展开大悬浮 `(12,710,366,100)`、收缩39pt胶囊 `(20,792,350,39)` 居中、邻胶囊及配对阴影处理、已验证顶部装饰线处理和原横滑手势；不替换标题、不改内容或字体。不扩大未知布局支持范围：外观仍保守限制于已验证 iOS16.6、390×844 竖屏、安全区47/34，冷启动收缩态仍需先展开建立绑定。

## 编辑/浏览交接

定位到旧实现的三处顺序风险：changed通知调用PrepareLayout先拆后等布局；Stable无条件拒绝动画；Restore在动画中推迟清除旧transform。现在通知只请求原生布局，不先拆有效前景外观。原生layout前恢复精确归属位移，layout后应用已验证新路径，两端包在同一个CATransaction，保持原生动画及递归守卫。

进入编辑不能沿用浏览裁剪输入；退出编辑不能让旧位移进入浏览。已验证空编辑材质的背景mask在新浏览目标通过完整验证前保留，重复编辑布局原位更新同一shape，不反复拆装；外部所有权、身份、父节点、bounds或窗口变化立即保守恢复。新浏览目标通过检查后，在同一布局事务内替换旧空背景。

几何动画只在单次交接意图或系统keyboard通知给出的真实duration内放行，要求存在有限的presentation几何且动画仅为原生position/bounds；未知transform/opacity/组合动画仍回退。原生动画不取消、不全局禁用、没有任意sleep或0.25秒延迟恢复。保留原有浏览用的有界displaylink（最多2秒、6个稳定tick停止），它只更新已绑定背景路径，不是采集器，也不是常驻轮询。后台/方向变化按归属恢复。

## 验证及限制

`python3 tests/verify.py`：
- 真实19帧/80tick既有浏览trace几何回放；1001点反向插值、3773次合成横滑、邻胶囊及阴影/装饰线回归。
- 提取生产补全函数执行的delete→typing→ready、IME、选区、保护、取消、失效及keyboard路径；4096允许判定和256删除判定组合；既有碰撞/背景归属回归保留。
- 提取实际PrepareLayout/Refresh/Layout函数执行已知“通知→原生layout→通知”及逆序、1000次进出反转、递归原实现单次调用、输入mask清除/旧位移清除。`tests/handoff.py --legacy-notification` 应在旧通知先拆顺序下断言失败。UIKit身份/bounds适配器、CA合成和实际像素不由此shim模拟。
- 固定12pt灰白居中、128种编辑拒绝位；单ctor/dylib、无console/capture/pref-toggle、三个旧包冲突和精确filter契约。

`completion_state.c` 保留为旧持久策略的历史纯函数回归；该偏好状态机不由0.2.0生产代码加载。

本地为Linux，无Xcode/UIKit运行环境，UIKit XCTest fixture仅保留，不宣称运行通过。真正进出编辑尚无连续实机轨迹；现有trace属于浏览收展，不能用它证明编辑转场修复。**仍需实机验收点击编辑、返回浏览和快速反向操作有无native闪帧，以及输入命中、灰白居中、键盘同步、横滑和方向/前后台恢复。** 本版不要求新增采样，也没有采集入口。
