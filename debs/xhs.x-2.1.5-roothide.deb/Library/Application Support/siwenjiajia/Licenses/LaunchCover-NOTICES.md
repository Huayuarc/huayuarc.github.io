# Launch cover source attribution

This integration adapts the user's supplied Yunji 1.0.2 source archive:

- worse_query technique: Taj C (forcequit / forcequitOS),
  https://github.com/forcequitOS/worse_query, GPL-3.0-or-later.
- WQFiles / WQManager access and cache-recovery helpers, as adapted in Yunji:
  https://github.com/kolbicz/WQFiles, kolbicz, GPL-3.0-or-later.
- GestaltX launch-artwork files, images and store:
  https://github.com/huamidev/GestaltX, Copyright (C) 2026 huamidev,
  GPL-3.0-only, with Yunji's operation/storage integration.

The adapted access code is XHSLaunchCoverAccess.m and
XHSLaunchCoverCacheSafety.h. Snapshot logic is XHSLaunchCoverStore.m;
the Xiaohongshu-specific UI is XHSLaunchCoverFeature.m. Corresponding source
is in this project. The full GNU GPL v3 text is in LaunchCover-GPL-3.0.txt.

Changes: restrict the target to the current Xiaohongshu container; require a
worse_query lease before file access; conservative OS and runtime gating;
preserve metadata, verify writes and retain a durable transaction journal;
adapt the cropper to the Xiaohongshu settings panel. This is not an unmodified
upstream binary and does not imply endorsement by upstream developers.
