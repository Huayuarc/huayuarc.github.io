# Banana Audio Service

独立维护的公共音频特征服务，供 Lunora、音乐触感及其他越狱插件订阅。
1.0.0 从 Lunora 1.0.8 的 `Companions/AudioSnapshotServer2` 原样提取。
1.0.1 按用户要求增加服务开关与设置内重载动作；采样、分析算法和 MSH2 协议保持原样。
1.0.2 修正设置页 Root.plist 的 title/items 字典结构与明确标题，解决此前数组结构无法被页面加载器正常消费的问题；音频运行源码保持 1.0.1 版本。
1.0.3 增加旧采样器保护：检测当前越狱注入目录中的 AudioSnapshotServer.dylib，以及当前进程已加载的同名旧模块。
1.0.4 将磁盘判定改为旧 dylib 与对应有效 plist 同时存在，并且 Filter.Executables 匹配音频服务；仅保留 dylib、移走 plist 不再锁定开关。

| 项目 | 值 |
| --- | --- |
| Package | `iya.banana.audioservice` |
| Version | `1.0.4` |
| 系统 | iOS 15+；本次提取未扩展原有实机验证范围 |
| 架构 | arm64 / arm64e；分别提供 Rootless / RootHide DEB |
| 注入文件 | `BananaAudioService.dylib` / `BananaAudioService.plist` |
| 数据接口 | `MSH2`，UDP `127.0.0.1:44333` |
| 原始项目 | AudioSnapshotServer2，Ryan Nair，MIT |

## 服务边界

- 仅在 `mediaserverd` / `audiomxd` 中按系统 `audiomxd_enabled` 选择一个进程启动；不注入应用。
- 输出系统混音特征：64 点波形、64 段频谱、RMS、峰值、采样率及状态标志。不是单 App 音轨。
- 原始 PCM 留在被选中的音频服务进程中；只发送特征数据。
- 最多 32 个客户端；各自选择特征和 5–60 Hz 发送频率。
- 客户端每 5 秒续订，15 秒无续订后过期；最后一个订阅退出后停止采样与分析。
- 设置 → Banana Audio Service 提供“启用服务”（默认开启）与“重载音频服务”，支持英文、简体中文、繁体中文。
- 禁用通过 Darwin 通知在控制队列清空订阅、停止采样和分析并拒绝新订阅；不在实时音频线程读设置。启用后等待客户端正常续订，现有客户端通常在 5 秒内恢复。
- 禁用时仍保留注入、生命周期追踪与本机监听，便于重新启用；停止的是采样、分析和特征输出，不尝试运行时卸载钩子。
- 重载按钮在确认后分别执行固定的 `killall -9 mediaserverd` 与 `killall -9 audiomxd`，提示全部／部分／失败结果；不执行 shell，不接受任意进程参数，不重启设备。
- 重载权限及设置通知在音频服务沙箱中的行为仍需测试机验证；失败时设置页给出 root 终端命令。
- 检出旧采样器时，在打开端口和安装钩子前退出启动；设置页开关显示关闭并置灰，显示三语言原因提示，保留用户原开关偏好。
- 如果运行后旧注入配置重新启用，下一次订阅／续订请求会清空现有订阅并停止本服务；设置页重新进入时也会刷新保护状态。不增加常驻文件扫描计时器。
- 磁盘判定要求旧 dylib 与对应 plist 同时存在，且原 V1 格式的 Filter.Executables 数组包含音频服务目标。音频进程检查自身名称，Settings 检查两个音频目标；支持 OpenStep、XML 和二进制 plist。仅留 dylib、移走 plist，或 Filter 不匹配，不锁定开关。
- 另检查当前进程已加载的旧模块，不凭 V1 包安装记录锁定。Settings 无法直接检查另一音频进程的模块；移走 plist 后仍需手动重载音频服务，释放可能已加载的旧实例。
- UDP 端口绑定失败仍会阻止安装钩子；端口占用本身不能区分旧服务与正常运行的新服务，因此不直接用于设置页的 V1 提示。
- 波形绘制、音乐触感和界面仍由消费插件负责。

## 构建与验证

需要本机已有的 Theos、iPhoneOS 18.5 SDK 及 RootHide 工具链支持；项目不引用 Lunora 目录参与构建。

```sh
make -C Tests clean test
python3.11 scripts/check_settings.py
make clean package THEOS_PACKAGE_SCHEME=rootless LUNORA_AUDIO_DIAGNOSTICS=0
make clean package THEOS=/Users/hades/theos-roothide THEOS_PACKAGE_SCHEME=roothide LUNORA_AUDIO_DIAGNOSTICS=0
python3.11 scripts/verify_release.py
```

必须顺序构建两种包。此机器的 RootHide 使用独立 Theos 路径；其他机器替换 `THEOS` 路径即可。
`make package` 不安装、不重启服务。正式构建保持诊断关闭；保留 `LUNORA_AUDIO_DIAGNOSTICS` 名称以避免改动现有运行源码。
提取来源与原始哈希见 `provenance/lunora-1.0.8.json`，开关控制、设置修复、旧服务保护、注入配置判定分别另记在 `provenance/service-controls-1.0.1.json`、`provenance/settings-fix-1.0.2.json`、`provenance/legacy-guard-1.0.3.json`、`provenance/injection-guard-1.0.4.json`。产物位于 `packages/`，旧版双包保留。

## 客户端接入

公共协议头为本项目根目录的 `MSHFProtocol.h`；可直接复用现有客户端，保持协议头一致。
消费插件改依赖时使用 `Depends: iya.banana.audioservice (>= 1.0.1)`；本次未改任何消费插件的源码或依赖。
现有客户端运行协议不变；包管理关系需要另外迁移，不能混为同一项兼容验证。
最小 C++ 接入示例是 `Tests/DeviceProbe.cpp`：发送 Subscribe，接收并校验 Feature，退出时发送 Unsubscribe。
长期客户端应保持独立随机 session、递增请求 sequence、5 秒续订及服务重启后的重新订阅。

## 安装边界

按用户要求，不声明 `Conflicts`、`Breaks`、`Replaces` 或旧服务 `Provides`，不添加卸载脚本。
独立包采用新的注入文件名；仅移动旧文件不会清除 dpkg 的所有权记录，因此不复用旧包安装路径。
V1 不再发布过渡版；V2 将改为直接依赖本包后发布。本次没有修改任何消费插件。
旧机手动切换时，移走旧 `AudioSnapshotServer.plist` 即可停用其后续注入，旧 dylib 可以保留；也可以移走旧采样 dylib。只移走 Lunora 主 dylib 不会停掉旧采样器。
旧 `AudioSnapshotServer.plist` 可留在原包；新包不覆盖、删除或修改它。
已运行进程中的旧采样器会继续占用同一 UDP 端口，需测试者自行重载音频服务，使新采样器接手。
两个采样器不能同时作为有效服务运行；本次保留既有运行代码的端口绑定与启动逻辑。

首次安装后，已运行的音频进程可能尚未加载注入。可在本服务设置中确认重载音频服务，或由测试者在 root 终端手动重载；安装包没有自动重启动作。

## 实机验收

```sh
make -C Tests device-probe
```

将签名后的 `Tests/DeviceProbe` 放到测试机运行；播放音乐后检查非零 server / epoch、正确采样率和随声音变化的特征。
随后验证两个客户端并发、单客户端退出、最后客户端退出、开关即时停止与恢复、禁用状态下服务重载、设置语言切换、重载权限及结果、扬声器 / 蓝牙 / AirPods 切换及进程稳定性。
本地辅助测试和 DEB 静态验证不能替代这些实机验收。

## License

Based on AudioSnapshotServer2 by Ryan Nair, MIT License. Original copyright and license are retained in `LICENSE`; upstream and Lunora-local history are recorded in `UPSTREAM.md`.
