# Corresponding source: wiki.qaq.apelin.agent-tools.assembler 1.0.0

The `apelin-assembler` executable in this package contains Keystone, which
is licensed under the GNU General Public License version 2 only (`COPYING`
beside this file; LLVM-derived parts also under `LLVM-LICENSE.TXT`). You may
copy, modify and redistribute it under that license. Apelin's own code in it
is MIT (`../Apelin/LICENSE`).

The complete corresponding source of this executable, with the scripts used
to build and package it, is:

- `wiki.qaq.apelin.agent-tools.assembler_1.0.0_source.tar.xz` (SHA-256 `c879e9930ed3d0f04b63b9876044926240d91516ff9d5edae9d6d76938081b2c`), published beside this
  package wherever this package is published;
- and, equivalently, these public repositories at these revisions:
  - Apelin, https://github.com/owngoal-dev/Apelin at commit `27fab10e80ad5cc9af15beb79413306f2e213220`:
    `Packages/ApelinToolHost` and `Extensions/AgentTools/Disassembler`;
  - libkeystone-spm (Keystone as a Swift package),
    https://github.com/Lakr233/libkeystone-spm at commit `3ff184008e1ba49577b944579cd32d32c78451b5`.

To rebuild: install Xcode and run
`Extensions/AgentTools/Disassembler/Scripts/build-agent-tools.sh` in an
Apelin checkout. The archive holds that tree under `Apelin/`, and the two
Swift packages it depends on under `Dependencies/` (libkeystone-spm, and
libcapstone-spm, which the same package graph names); to build from the
archive without the network, first run, in
`Apelin/Extensions/AgentTools/Disassembler`,
`swift package edit libkeystone-spm --path ../../../../Dependencies/libkeystone-spm`
and the same for libcapstone-spm.
