# 应用修改器 · 脚本怎么用

适用版本：1.2.16。看完这篇你能写出「震动一下 + 记日志」「把 VIP 判断改成真」「把数字翻倍」这类脚本。不需要会 Objective-C，脚本语言只有几条规则。

> 说明：1.2.4 起脚本引擎已从 JavaScriptCore 换回自研的安全求值器，下面的语法和函数就是这套语言的全部能力。
> 标准 JavaScript 的部分习惯写法（+=、Math.floor、模板字符串、do...while）会报语法错误，请按本文写法来；
> `i++` / `i--` 与 `数组.forEach(function(x) { … })` 是支持的。

---

## 一、先搞清楚：有两种脚本，别写错地方

打开 App → 选一个应用 → 新建/编辑一条「修改项」，编辑页从上到下有这几段：
`目标方法` → `实施方式` → `返回值` → `自定义代码行为` → `其它`。

两种脚本分别藏在这两个地方：

| 项目 | 动作脚本 | 返回值脚本 |
| --- | --- | --- |
| 在哪写 | `自定义代码行为` → 点「写一段动作脚本」→ 全屏编辑页 | `返回值` 段 → 「覆盖类型」选 `自定义脚本` → 下面出现代码框 |
| 干什么 | 只做事：震动、飘提示、记日志、调方法、改成员变量 | 只算一个值，当成方法的新返回值 |
| 影响返回值吗 | 不影响，返回值仍由实施方式 / 覆盖类型决定 | 影响，最后一句算出来的值就是返回值 |
| 什么方法能用 | 全都能，包括 void 没有返回值的方法 | 有返回值的方法才有意义 |
| 语法 | 完全一样，都能用 let / if / 全部函数 | 一样 |
| 两个能一起用吗 | 能，先跑动作脚本，再算返回值 | 能 |

一句话选法：
- 想知道方法有没有被调到 → 实施方式选 `只统计调用`，写动作脚本 `vibrate()`。
- 想把 isVIP 变成真 → 实施方式选 `替换实现`，覆盖类型选 `布尔值` 就行，用不上脚本。
- 真假要看情况 → 覆盖类型选 `自定义脚本`，写返回值脚本。
- 原方法照跑、顺手做点别的 → 实施方式选 `原方法后改返回值`，写动作脚本。

执行顺序（一次方法调用内）：记命中次数 → 跑动作脚本 → 跑原方法 / 算返回值。

---

## 二、30 秒写出第一个脚本

目标：确认某个方法到底有没有被调用。

1. 修改项里填好类名和方法名，`作用域` 一般是 `实例方法（-）`。
2. `怎么改` 选 `只统计调用`（原方法照常跑，什么都不破坏）。
3. `自定义代码行为` → 点进全屏页，输入：

```
vibrate()
log("被调用了，第" + str(hits) + "次")
```

4. 右上角先点 `试算一次` 看看语法有没有问题，再点 `保存`。
5. 回到应用列表保存规则，杀掉目标 App 重新打开。
6. 触发那个功能：手机应该震一下；回到「注入状态」页能看到日志条数在涨。

---

## 三、语法速查

### 分句

一行一句，也可以用 `;` 隔开。空行随便加。

```
let a = 1
let b = 2; log(a + b)
```

### 注释

只支持 `//` 到行尾。`#` 和 `/* */` 都不支持。

```
// 这行是说明，不会执行
vibrate()   // 行尾也行
```

### 变量

`let 名字 = 值`，也可以直接 `名字 = 值`。名字用英文字母、数字、下划线，必须字母或 `_` 开头。可以重复赋值。

```
let n = int(original)
n = n + 1
```

### 字符串

必须用双引号 `" "`。拼接用 `+` 或 `concat()`。

```
let s = "第" + str(hits) + "次"
```

### 判断

```
if (hits > 3) {
  vibrate()
} else {
  log("还没到 3 次")
}
```

花括号是必须的。

### 循环（1.1.0 起）

四种循环写法，都有 10 万次保护，超出自动停止并报「循环超过 10 万次」。

注意：计数器写 `i = i + 1`，也可以写 `i++` / `i--`（1.2.10 起支持后缀自增自减）；**仍不支持 += / -=**。

```
// for 数次数
for (let i = 0; i < 5; i = i + 1) {
  log("第 " + str(i) + " 次")
}

// for..in 遍历集合：数组给元素、字典给键、字符串给字符
for (let x in arr(3, 5, 7)) { log(str(x)) }        // 3、5、7
for (let k in dict("a", 1, "b", 2)) { log(k) }     // a、b（字典给的是键）
for (let c in "abc") { log(c) }                    // a、b、c

// while 条件循环
let n = 0
while (n < 3) {
  log(str(n))
  n = n + 1
}

// break / continue
for (let i = 0; i < 10; i = i + 1) {
  if (i == 2) { continue }   // 跳过这一次
  if (i == 5) { break }      // 提前结束整个循环
  log(str(i))                // 只会打 0 1 3 4
}

// forEach 遍历（1.2.10 起）：数组给元素、字典给键、字符串给字符
// 括号可带可不带，教程里的带括号写法从 1.2.12 起支持
let tags = [1001, 1002, 1003]
tags.forEach(function(tag) {
  log("tag=" + str(tag))
})
tags.forEach(function(tag, i) {   // 第二个参数是序号，从 0 开始
  log(str(i) + " → " + str(tag))
})
```

### 数组 / 字典

构造：

```
let a = [1, 2, 3]                       // 数组字面量
let b = arr(4, 5, 6)                    // arr() 函数
let r = range(0, 5)                     // [0, 1, 2, 3, 4]（从 0 到 5，不含 5）
let d = {"name": "小明", "age": 18}      // 字典字面量（键必须是字符串）
let e = dict("k1", "v1", "k2", "v2")    // dict() 函数，键值对成对给
```

读：数组按序号（从 0 起）、字典按键、字符串也能按下标取字符。

```
a[0]              // 1
d["name"]         // "小明"
"hello"[1]        // "e"
```

写：要可变数组 / 可变字典才写得了；写不了会报中文错误，不会崩。

```
d["age"] = 19     // d 要是可变字典
m[2] = 999        // m 要是可变数组，下标越界报「数组下标越界」
```

提醒：数组字面量、`arr()` / `dict()` / `range()` 等构造出来的是只读副本，对它们 `push()` / 下标赋值会报「要可变数组」；要改元素，请对宿主传进来的、本来就是可变的容器操作（例如宿主对象的可变属性 `self.items`）。

### 运算符

- 算术：`+ - * / %`。两个整数相除得整数（7 / 2 = 3）；要小数把任一边转小数（`num(7) / 2` 或 `7 / num(2)`）。
- 比较：`== != > < >= <=`
- 逻辑：`&& || !`
- 三目：`条件 ? 这个 : 那个`
- 取属性：`self.title`（点号，走 KVC）

### 真假怎么算

空值、0、空字符串算假，其它算真。字面量可以写 `true` / `false` / `YES` / `NO` / `nil` / `null`。

### 脚本的结果

没有 `return` 关键字，最后一句的值就是结果（返回值脚本靠这个）。动作脚本的结果没人要，写什么都行。

---

## 四、内置变量（不用声明，直接用）

| 变量 | 是什么 |
| --- | --- |
| `self`（或 `this`） | 被调用的那个对象；类方法时是类本身 |
| `arg1` `arg2` `arg3` ... | 第 1、2、3 个参数。写超过方法真实参数个数就取到空值 |
| `argc` | 参数个数 |
| `original` | 原方法的返回值。只有实施方式选 `原方法后改返回值` 时才有值 |
| `hits` | 这条规则被命中第几次（含本次），从 1 开始 |
| `cls` | 类名字符串 |
| `sel` | 方法名字符串 |
| `now` | 当前时间戳，秒，带小数 |
| `self.属性名` | 读对象的属性或无参方法，例如 `self.isPro`、`arg1.length` |

---

## 五、函数总表

### 1. 算数值 / 转换

| 写法 | 说明 |
| --- | --- |
| `if(条件, 真时的值, 假时的值)` | 条件取值（三个参数都要写） |
| `int(x)` | 转整数 |
| `num(x)` | 转小数 |
| `str(x)` | 转字符串 |
| `bool(x)` | 转真假 |
| `len(x)` | 字符串长度 / 数组个数 |
| `abs(x)` `floor(x)` `ceil(x)` `round(x)` | 绝对值、下取整、上取整、四舍五入 |
| `pow(底, 指数)` | 幂 |
| `min(a, b, ...)` `max(a, b, ...)` | 取最小 / 最大，参数个数不限 |
| `random(小, 大)` | 区间随机整数 |
| `time()` | 当前时间戳（整数秒） |

### 2. 处理文字

| 写法 | 说明 |
| --- | --- |
| `upper(s)` `lower(s)` `trim(s)` | 转大写、小写、去首尾空格 |
| `contains(s, "关键字")` | 是否包含 |
| `hasPrefix(s, "http")` `hasSuffix(s, ".png")` | 开头 / 结尾判断 |
| `substr(s, 起始)` `substr(s, 起始, 长度)` | 截取 |
| `replace(s, "旧", "新")` | 替换 |
| `concat(a, b, ...)` | 拼接 |

### 3. 数组 / 字典操作（1.1.0 新增 30+）

| 写法 | 说明 |
| --- | --- |
| `arr(1, 2, 3)` | 把参数合成一个数组 |
| `dict("k", v, ...)` | 键值对两两成组合成字典，键必须是字符串 |
| `range(0, 5)` `range(5)` | 整数数组；`range(0,5)`=[0,1,2,3,4]，`range(5)`=[0..4]，`range(5,0)` 倒着给 |
| `repeat(x, n)` | 把 x 重复 n 次组成数组 |
| `split("a,b", ",")` | 字符串按分隔符拆成数组 |
| `join([...], "分隔符")` | 数组拼成字符串 |
| `push(a, x)` `pop(a)` | 尾部加 / 取出并移除最后一个（要可变数组） |
| `shift(a)` `unshift(a, x)` | 头部取出并移除 / 头部插入（要可变数组） |
| `insert(a, 序号, x)` `remove(a, 序号)` | 中间插入 / 删除（要可变数组） |
| `indexOf(a, x)` | 找元素位置，找不到返回 -1 |
| `slice(a, 起, 止?)` | 截取一段（不含止），不填止 = 到末尾 |
| `reverse(a)` | 倒序出新数组 |
| `sort(a)` | 排序：数字比大小，其它按文字 |
| `sum(a)` `avg(a)` | 求和 / 平均（空数组 avg 给 0） |
| `first(a)` `last(a)` | 第一个 / 最后一个元素 |
| `unique(a)` | 去重 |
| `shuffle(a)` | 打乱顺序 |
| `flatten(a)` | 把嵌套数组摊平（任意深度） |
| `keys(d)` `values(d)` | 字典的所有键 / 所有值 |
| `hasKey(d, "k")` | 字典里有没有这个键 |
| `setKey(d, "k", v)` `removeKey(d, "k")` | 写键 / 删键（要可变字典） |
| `merge(d1, d2)` | 合并两个字典，右边的覆盖左边同名键 |
| `zip(a, b)` | 两数组按位配对成 [[a0,b0],[a1,b1],...]，取短的那个长度 |

### 4. 数组进阶（1.2.6 新增）

| 写法 | 说明 |
| --- | --- |
| `containsAll(a, x, y, ...)` | 数组是否包含后面给的所有值 |
| `containsAny(a, x, y, ...)` | 数组是否包含后面给的任意一个值 |
| `nth(a, 序号)` | 取第几个元素，越界给空值 |
| `take(a, n)` | 取前 n 个 |
| `drop(a, n)` | 丢掉前 n 个 |
| `compact(a)` | 去掉数组里的空值 |
| `dedupe(a)` | 去重（保留第一次出现） |
| `chunk(a, n)` | 每 n 个一组切成二维数组 |
| `union(a, b, ...)` | 多数组 / 值合并去重 |
| `difference(a, b)` | 在 a 里但不在 b 里的元素 |
| `intersection(a, b)` | a、b 都有的元素 |

### 5. 字符串扩展 / JSON（1.1.0 新增）

| 写法 | 说明 |
| --- | --- |
| `repeatStr("ab", 3)` | 把字符串重复 n 遍（n 最多 10000） |
| `reverseStr(s)` | 倒序 |
| `charAt(s, 序号)` | 取第几个字符，越界给空串 |
| `indexOfStr(s, "x")` | 找子串位置，找不到 -1 |
| `padLeft(s, 宽)` `padRight(s, 宽)` | 补足到指定宽度，默认补空格 |
| `padLeft(s, 宽, "0")` `padRight(s, 宽, "0")` | 第三个参数指定补的字符 |
| `words(s)` | 按空白拆成词，空段去掉 |
| `lines(s)` | 按换行拆成行 |
| `format("你好{0}，{1}", [名字, 日期])` | 占位符替换；第二个参数给数组（或单个值） |
| `hex(255)` `bin(5)` `oct(8)` | 转 16 / 2 / 8 进制字符串 |
| `ord("A")` `chr(65)` | 字符转码点 / 码点转字符 |
| `jsonEncode(x)` | 数组 / 字典 → JSON 字符串 |
| `jsonDecode("...")` | JSON 字符串 → 数组 / 字典 |

### 6. 字符串进阶（1.2.6 新增）

| 写法 | 说明 |
| --- | --- |
| `startsWith(s, p)` `endsWith(s, p)` | 开头 / 结尾判断 |
| `capitalize(s)` | 首字母大写，其余不动 |
| `titleCase(s)` | 每个单词首字母大写 |
| `trimLeft(s)` `trimRight(s)` | 只去左边 / 只去右边空白 |
| `swapCase(s)` | 大小写互换 |
| `reverseWords(s)` | 单词顺序倒过来，单词本身不动 |
| `countOccurrences(s, p)` | p 在 s 里出现几次 |
| `removeAll(s, p)` | 把 s 里所有 p 删掉 |
| `ellipsis(s, n)` | 超长截断，多余的换成 … |
| `padStart(s, n, fill?)` `padEnd(s, n, fill?)` | 左 / 右补齐到 n 宽 |
| `charCodeAt(s, i)` | 第 i 个字符的码点，越界给 0 |
| `fromCharCode(c...)` | 码点转字符串，可给多个 |
| `base64Encode(s)` | 转 base64 |
| `base64Decode(s)` | base64 解码，不合法给中文错误 |
| `urlEncode(s)` `urlDecode(s)` | URL 编码 / 解码 |
| `uuid()` | 生成一个 UUID 字符串 |
| `randomString(n)` | 随机字母数字串，最长 4096 |
| `pluralize(s, n)` | 英文复数：n==1 用原形，否则加 s / es / ies |
| `truncateWords(s, n)` | 最多保留 n 个单词，多余的加 ... |

### 7. 数学与位运算（1.1.0 + 1.2.6 扩充）

| 写法 | 说明 |
| --- | --- |
| `sqrt(x)` `ln(x)` `log10(x)` `log2(x)` | 开方 / 自然对数 / 常用对数 / 2 为底对数 |
| `sin(x)` `cos(x)` `tan(x)` | 三角函数（弧度） |
| `clamp(x, 低, 高)` | 夹到区间里（低高写反会自动换） |
| `wrap(x, 低, 高)` | 绕回区间，像角度 370° → 10° |
| `sign(x)` | -1 / 0 / 1 |
| `lerp(a, b, t)` | 线性插值：a + (b-a) × t，t 常用 0～1 |
| `pi` `e` | 圆周率 / 自然常数 |
| `bitAnd(a, b)` `bitOr(a, b)` `bitXor(a, b)` | 按位与 / 或 / 异或 |
| `bitNot(a)` | 按位取反 |
| `shiftLeft(a, n)` `shiftRight(a, n)` | 左移 / 右移 |

### 8. 数字进阶（1.2.6 新增）

| 写法 | 说明 |
| --- | --- |
| `isNaN(x)` | 转不成数字返回真 |
| `isNumeric(x)` | 能不能转成数字 |
| `toFixed(x, n?)` | 固定几位小数（默认 2，最多 12），返回字符串 |
| `toPrecision(x, n?)` | 有效数字位数（默认 3），返回字符串 |
| `trunc(x)` | 去掉小数部分 |
| `floorN(x, n?)` `ceilN(x, n?)` `roundN(x, n?)` | 保留 n 位小数做下取整 / 上取整 / 四舍五入（默认 0） |
| `gcd(a, b)` `lcm(a, b)` | 最大公约数 / 最小公倍数 |
| `isPrime(x)` | 是不是质数 |
| `factorial(n)` | 阶乘，n 最大 20 |
| `fibonacci(n)` | 第 n 个斐波那契数，n 最大 90 |
| `clamp01(x)` | 夹到 0～1 |
| `randomInt(a, b)` `randomFloat()` | 随机整数（闭区间）/ 随机小数 0～1 |
| `degToRad(x)` `radToDeg(x)` | 角度 ↔ 弧度 |
| `hypot(a, b)` | 斜边：√(a²+b²) |

### 9. 时间（1.2.6 新增）

| 写法 | 说明 |
| --- | --- |
| `timestamp()` | 当前时间戳，整数秒 |
| `now()` | 当前时间戳，毫秒 |
| `yyyy()` `mm()` `dd()` `weekday()` | 当前年 / 月 / 日 / 星期（英文缩写） |
| `formatDate(ts, "yyyy-MM-dd HH:mm")` | 时间戳按格式转字符串，格式可自定义 |
| `parseDate("2026-09-01 10:30")` | 把日期字符串解析成时间戳 |
| `dateAdd(ts, days)` | 时间戳加几天 |
| `dateDiff(a, b)` | 两个时间戳相差几天 |
| `daysInMonth()` | 当前月有几天 |
| `isLeapYear()` | 今年是不是闰年 |
| `timeAgo(ts)` | 相对时间：x 秒 / 分钟 / 小时 / 天前 |

### 10. 逻辑 / 类型（1.2.6 新增）

| 写法 | 说明 |
| --- | --- |
| `isNil(x)` `isNull(x)` | 是不是空 |
| `isEmpty(x)` | 空字符串 / 空数组 / 空字典 / 空值 |
| `ifNull(a, b)` | a 为空时返回 b，否则返回 a |
| `coalesce(a, b, ...)` | 从左到右取第一个不为空的值 |
| `not(x)` | 取反 |
| `ternary(条件, a, b)` | 三目函数的写法 |
| `assert(条件, msg?)` | 条件不成立时报错，msg 可自定义 |
| `throwSafe(msg)` | 主动报一个错误 |
| `typeOf(x)` | 返回类型名：nil / int / float / str / array / dict / object |
| `isNumber(x)` `isString(x)` `isArray(x)` `isDict(x)` | 类型判断 |
| `toInt(x)` `toFloat(x)` | 转数字，转不了报中文错误 |
| `toBool(x)` `toStr(x)` | 转真假 / 转字符串 |

### 11. 看对象里有什么

| 写法 | 说明 |
| --- | --- |
| `get(对象, "属性名")` | 按名字取属性（同 prop） |
| `prop(对象, "属性名")` | 读属性（KVC） |
| `getIvar(对象, "_name")` | 读成员变量（带下划线那种） |
| `classname(对象)` | 取类名字符串 |
| `inspect(对象)` | 把对象摊开：类名 + 父类 + 前 20 个属性 / 成员变量的当前值（每个值截 60 字，读不到的写 <读不到>） |
| `trace()` | 这次调用的快照：类名 · 方法名 · 第几次 · 每个参数的类名与值 · original · self。最常用写法是 `log(trace())` |

### 12. 做事（动作函数，动作脚本里最常用）

| 写法 | 说明 |
| --- | --- |
| `vibrate()` `vibrate(0)` `vibrate(1)` `vibrate(2)` | 震动，轻 / 中 / 重 |
| `toast("文字")` | 屏幕下方飘一条提示，不打断应用，调试首选（默认停留 1.6 秒、字号 14） |
| `toast("文字", 秒数)` `toast("文字", 秒数, 字号)` | 秒数 0.3～10、字号 10～28，写超了自动夹到边界，不报错。例：`toast("看这里", 5, 24)` |
| `alert("标题")` `alert("标题", "内容")` | 真弹窗，会打断目标应用，别放在高频方法里；弹窗自带「复制」按钮。在桌面（SpringBoard）里会自动改用 toast 显示（停 3 秒），免得把桌面卡住 |
| `log(值1, 值2, ...)` | 记一条日志，去「注入状态」页回看；返回第一个值，可以套在表达式里 |
| `setIvar(对象, "_count", 0)` | 写属性 / 成员变量 |
| `call(对象, "方法名")` `call(对象, "setHidden:", 1)` | 调对象的方法，冒号个数必须等于参数个数 |
| `callClass("类名", "方法名", 参数...)` | 调类方法 |
| `delay(秒, 动作...)` | 延后执行，0～60 秒，在主线程跑；里面的 log() 也会进日志 |

补充（1.2.6 新增的动作函数）：

| 写法 | 说明 |
| --- | --- |
| `print(a, b, ...)` `console(a, b, ...)` | 记一条普通日志（同 log） |
| `warn(msg)` `error(msg)` | 记一条错误日志（状态页会标红） |
| `sleep(毫秒)` | 当前线程停一停，最多 5000 毫秒，别在 UI 线程用 |
| `timeout(毫秒, 动作...)` `interval(毫秒, 动作...)` | 延后 N 毫秒执行 / 每 N 毫秒执行一次的动作（到 60 秒封顶） |
| `env()` | 返回设备 / 应用信息字典：appVersion、bundleID、osVersion、deviceModel、screenW、screenH |
| `openURL("https://...")` | 打开链接 |
| `copyText("文字")` `pasteText()` | 复制 / 粘贴剪贴板 |
| `deviceModel()` `screenSizeW()` `screenSizeH()` `osVersion()` `appVersion()` `bundleID()` | 设备 / 系统 / 应用信息 |
| `batteryLevel()` | 电量百分比（0～100） |
| `memoryFree()` `diskFree()` | 剩余内存（不可用给 -1）/ 剩余磁盘（MB） |
| `runCmd(...)` | 已禁用，报「没有 root 通道」 |
| `killApp()` `relaunchApp()` | 已禁用，报「在注入环境禁用」 |

关于线程（重要）：`toast` / `alert` / `vibrate` 会自动切回主线程，随便用。
`call()` 在原方法所在的线程直接调，要动界面就包一层 `delay(0, call(...))`。

想把内容看全 / 拷走：

- `log(trace())`：一句话记下「这个方法这次被调用时发生了啥」，参数是啥类型、值是什么、原返回值都在里面。
- `log(inspect(self))` 或 `alert("看看", inspect(arg1))`：看某个对象里到底装了什么。
- 注入状态页点一条规则 → 弹窗里有「复制全部日志」和「看全部日志」；后者是独立页面，全部 50 条都在，能滚动、能长按全选复制。

### 13. 操作控件（0.0.23 + 1.2.5 视图增强）

第一个参数都给「视图」：`self`（命中的对象本身是视图时）、`arg1`、或下面查找函数的结果；
给的是控制器（UIViewController）时会自动取它的 `view`。参数不是视图只会记一条错误，不会让应用崩掉。

先找控件（有返回值，只能在主线程用）：

| 写法 | 说明 |
| --- | --- |
| `subviewCount(视图)` | 有几个子视图 |
| `subview(视图, 序号)` | 第几个子视图，序号从 0 起；越界给空值不报错 |
| `superview(视图)` | 它的父视图 |
| `viewWithTag(视图, tag)` | 按 tag 找（含自己和所有后代） |
| `findView(根视图, "类名")` `findView(根视图, "类名", 第几个)` | 按类名深度优先找，第几个从 1 起；最多摸 5000 个节点，找不到给空值 |

再动控件（纯做事，会自动切回主线程）：

| 写法 | 说明 |
| --- | --- |
| `hide(视图)` `hide(视图, 1)` `hide(视图, 0)` | 隐藏（默认隐藏，0 = 显示回来） |
| `alpha(视图, 0.3)` | 透明度 0～1，超出自动夹紧 |
| `removeView(视图)` | 从父视图上摘掉（重进这个界面通常会重新出现） |
| `setFrame(视图, x, y, 宽, 高)` | 一次给四个数 |
| `setSize(视图, 宽, 高)` `setOrigin(视图, x, y)` | 只改大小 / 只改位置 |
| `relayout(视图)` | 让它重新布一次版（setNeedsLayout + layoutIfNeeded） |
| `enable(视图)` `enable(视图, 0)` | 开 / 关交互，按钮之类连 enabled（灰不灰）一起管 |
| `setText(视图, "文字")` | 改文字：UILabel / UITextField / UITextView 改 text，UIButton 改标题；别的控件忽略 |

1.2.5 视图增强：

| 写法 | 说明 |
| --- | --- |
| `setImage(v, "star")` | 换图。支持 SF Symbol 名 / http 图 / 包内图 |
| `setColor(v, "#FF0000")` | 同时改背景与文字色 |
| `setBgColor(v, "red")` `setTextColor(v, "blue")` | 分开改背景 / 文字色 |
| `setCornerRadius(v, 8)` | 圆角 |
| `setBorder(v, 2, "#333")` `setBorderWidth(v, 2)` `setBorderColor(v, "#333")` | 描边（宽 / 色可单独改） |
| `scrollToTop(v)` `scrollToBottom(v)` | 滚到顶 / 底 |
| `bringToFront(v)` `sendToBack(v)` | 层级：提到最前 / 沉到最底 |
| `click(v)` `tap(v)` | 模拟点按（UIControl） |
| `resignFirstResponder(v)` `becomeFirstResponder(v)` | 交回 / 抢到键盘焦点 |
| `setPlaceholder(v, "请输入")` | 占位文字 |
| `setFontSize(v, 18)` | 字号 |
| `setTextAlignment(v, "center")` | 对齐：left / center / right |
| `setAccessibilityLabel(v, "...")` | 无障碍标签 |

1.2.13 视图增强（隐藏控件后填平空位）：

| 写法 | 说明 |
| --- | --- |
| `spread(容器)` | 把容器里还看得见的控件按顺序横向等分排开，填平隐藏后空出来的位置 |
| `spread(容器, "类名")` `spread(容器, [1000, 1004])` `spread(容器, [v1, v2])` | 只排指定的这些控件（类名 / tag 清单 / 视图清单三种都收） |
| `spread(容器, 过滤, "v")` | 第三个参数给 `"v"` 改成纵向等分（默认横向） |
| `spread(容器, 过滤, "c")` | 只挪位置不改大小：控件保持原尺寸、居中摆进自己那一格（宿主用约束把内容顶回去时用它） |
| `viewFrame(视图)` | 读它现在的位置尺寸，返回 `[x, y, 宽, 高]` 数组，配 `log` 用来确认 |

用法与实测范例见示例 H4。

颜色写法：`#RRGGBB`、`#RRGGBBAA`、英文名（red / blue / clear / ...）都行。

两条要记住的规矩：

1. 查找函数不在主线程时会直接报错（提示里会告诉你怎么改），因为宿主的方法经常在子线程被调到。
   不确定就把整段包起来：`delay(0, hide(findView(self, "UITabBar")))`。
2. 宿主自己 layoutSubviews 会把 frame 改回去，看着像「函数没生效」。两种办法：
   - 把规则挂在会反复调用的布局方法上（layoutSubviews / viewDidLayoutSubviews）；
   - 或者补一刀：`delay(0.3, setFrame(按钮, 10, 10, 120, 44))`。

---

## 六、脚本能做的事（一览）

- 确认某个方法到底有没有被调用、被调了几次（hits + log / vibrate）
- 把方法的返回值改成固定值，或按条件动态算（返回值脚本）
- 只在第一次 / 第 N 次命中时才生效（hits）
- 看参数里到底传了什么（str(arg1)、classname(arg1)、len(arg1)）
- 读对象内部状态（self.属性、prop、getIvar）
- 改对象内部状态（setIvar）
- 主动调用对象或类的其它方法（call / callClass）
- 隐藏 / 显示某个界面元素（hide(视图, 1)，也可以用 call(arg1, "setHidden:", 1)）
- 去掉底栏里的某个按钮、改控件大小位置、把灰掉的控件启用（findView / subview + hide / setSize / enable）
- 过滤：只有参数含某关键字时才动手（contains）
- 洗字符串：去掉广告词、截断、替换（replace / substr / removeAll / ellipsis）
- 延后做事、避开时序问题（delay / timeout）
- 屏幕提示、震动反馈、弹窗（toast / vibrate / alert）
- 把观察结果留成日志慢慢看（log / print，注入状态页）
- 批量处理：for / for-in 循环 + 数组下标 / 视图查找函数
- 结构化数据：数组 / 字典 + JSON 字符串互转
- 生成唯一标识、随机串（uuid / randomString）

做不到的事：不能自己定义函数；不能读写文件、不能发网络请求；call 只能调已有对象上的方法，不能随便新建 Objective-C 对象（脚本自己的数组 / 字典可以随便建）；runCmd / killApp / relaunchApp 已被禁用。

---

## 七、完整示例（可直接抄）

### A. 确认方法有没有被调用（最常用）

配置：`怎么改 = 只统计调用`；动作脚本：

```
vibrate()
log("命中 " + cls + " " + sel + "，第" + str(hits) + "次")
```

### B. 只在第一次命中时提示，之后闷声跑

```
if (hits == 1) {
  toast("规则生效了：" + sel)
}
```

### C. 看看参数里到底是什么

```
log("argc=" + str(argc))
log("arg1 类型=" + classname(arg1))
log("arg1 内容=" + substr(str(arg1), 0, 120))
```

### D. 只有参数里带关键字才动手

```
let s = str(arg1)
if (contains(s, "vip") || contains(s, "member")) {
  toast("抓到一次：" + s)
  vibrate(2)
}
```

### E. 读对象内部状态

```
log("标题=" + str(prop(self, "title")))
log("计数=" + str(getIvar(self, "_badgeCount")))
log("isPro=" + str(self.isPro))
```

### F. 改成员变量 + 刷新界面

```
setIvar(self, "_badgeCount", 0)
delay(0, call(self, "setNeedsLayout"))
```

setNeedsLayout 碰 UI，所以套了 `delay(0, ...)` 挪到主线程。

### G. 高频方法降噪：每 10 次记一条

```
if (hits % 10 == 1) {
  log("已经被调用 " + str(hits) + " 次")
}
```

### H. 隐藏某个传进来的视图

```
if (hits == 1) { log("准备隐藏：" + classname(arg1)) }
delay(0, call(arg1, "setHidden:", 1))
```

### H2. 去掉底栏里的一个按钮

挂在底栏所在类的布局方法上（例如 UITabBar 的 layoutSubviews），`怎么改 = 只统计调用`：

```
let bar = findView(self, "UITabBar")
hide(subview(bar, 2), 1)
```

subview 的序号从 0 起，所以这里去掉的是第 3 个。不确定有几个先写
`log("底栏有 " + str(subviewCount(bar)) + " 个")` 看一眼。

### H3. 改按钮大小 / 启用被禁用的控件

```
let btn = viewWithTag(self, 10)
setSize(btn, 120, 44)
relayout(btn)
enable(findView(self, "UISwitch"), 1)
```

如果宿主自己布局又把它改回去了，补一刀 `delay(0.3, setSize(btn, 120, 44))`。

### H4. 隐藏几个按钮后，剩下的均摊满整条（1.2.13 起）

隐藏底栏中间几个按钮后，原来的位置会空着一块。`spread(容器)` 把容器里还看得见的控件按顺序等分排开，
把空位填平；想读某个控件现在的位置尺寸确认效果，用 `viewFrame(视图)`（给 `[x, y, 宽, 高]`）。

三条要点：

1. 规则挂在**容器自己的布局方法**上（例如底栏类的 `layoutSubviews`），`怎么改 = 只统计调用`；
   脚本里一律用 `delay(0, …)` 包一层 —— 动作脚本跑在宿主原布局**之前**，不推到下一轮会被原布局盖回去。
2. 按钮不一定挂在容器的直接子层（很多底栏套了一层毛玻璃 `_UIVisualEffectContentView`）。
   容器直接子层里可见控件不到 2 个时，`spread()` 会自己往里找一层，找到第一层「可见控件 ≥ 2」的再排，
   所以直接写 `spread(self)` 通常就够。
3. 实在排不了（都隐藏了、只剩 1 个）会往「注入状态」写一条中文提示，同一条提示只写一次，不刷日志。

高德地图实测（类 `WINTabBar`、方法 `layoutSubviews`、只统计调用）：

```
// 隐藏中间 3 个按钮（tag 1001 / 1002 / 1003）
for (let tag = 1001; tag <= 1003; tag++) {
    let item = viewWithTag(self, tag)
    if (item) {
        delay(0, removeView(item))
    }
}
// 剩下的按钮均摊满整条，填平中间空出来的位置
delay(0, spread(self))
```

底栏宽 428 时，剩下两个按钮实测各占一半：`tag1000 x=0 w=214`、`tag1004 x=214 w=214`。
想自己核对加一句（高频方法记得降噪）：

```
if (hits == 1) {
  delay(0.1, log("1000 → " + str(viewFrame(viewWithTag(self, 1000)))))
}
```

只想排某几个、不用自动模式时，第二个参数给清单：`delay(0, spread(self, [1000, 1004]))`；
要竖着排（例如侧栏）再加第三个参数：`delay(0, spread(self, "UIButton", "v"))`。

1.2.15 起还多做一步：均摊完会把每个按钮**里面**的图标 / 文字整体挪到各自格子的正中间。
宿主通常按原来的窄宽度把图标和文字的位置写死，光把按钮拉宽会看到内容仍贴在左边。
这一步每帧算出来的结果一样（幂等），不会越挪越偏。
要是某个宿主用约束又把内容顶回左边，就连按钮尺寸也别动，改成第三个参数写 `"c"`：

```
delay(0, spread(self, nil, "c"))
```

按钮保持原大小，只把它整体居中摆进自己那一格。

1.2.16 起这一步用「位移变换」实现，不再直接改内容的位置：宿主切换选中项时会重写按钮里图标 / 文字的
位置（换灰 / 蓝图标那一下），而那一刻容器的 layoutSubviews 不一定再跑，改位置的做法会被顶回左边；
位移变换不会被宿主的 setFrame 清掉，所以反复点两个按钮，内容都一直待在各自格子的中间。

### I. 延时提示（避开启动阶段）

```
delay(3, toast("3 秒后才提示，不挡启动"))
```

### J. 返回值脚本：第一次假，之后真

配置：`覆盖类型 = 自定义脚本`；代码框：

```
hits == 1 ? false : true
```

### K. 返回值脚本：原返回值翻倍，但不超过 100

配置：`怎么改 = 原方法后改返回值`，`覆盖类型 = 自定义脚本`：

```
let n = int(original) * 2
min(n, 100)
```

### L. 返回值脚本：把返回的文字里的广告词去掉

```
let s = str(original)
s = replace(s, "广告", "")
s = replace(s, "赞助", "")
trim(s)
```

### M. 返回值脚本：按参数决定给真还是给原值

```
contains(lower(str(arg1)), "pro") ? true : original
```

### N. 返回值脚本：多行判断

```
let n = int(original)
if (n <= 0) {
  log("原值异常：" + str(n))
  1
} else {
  n
}
```

注意：if/else 里最后那一句就是分支的值，所以这段能当返回值用。

### O. 动作脚本 + 返回值脚本一起上

动作脚本（做事）：

```
if (hits == 1) { toast("VIP 判定已接管") }
log("hit " + str(hits) + " original=" + str(original))
```

返回值脚本（算值）：

```
true
```

### P. 用 for 统计数组

```
let a = [10, 20, 30, 40]
let total = 0
for (let i = 0; i < len(a); i = i + 1) {
  total = total + a[i]
}
log("合计 " + str(total) + "，平均 " + str(avg(a)))
```

### Q. 用 for-in 遍历字典

```
let d = {"a": 1, "b": 2, "c": 3}
let s = 0
for (let k in d) {
  s = s + d[k]
}
log("总和 " + str(s))    // 6
```

### R. break / continue 控制循环

```
for (let i = 1; i <= 10; i = i + 1) {
  if (i % 2 == 0) { continue }   // 偶数跳过
  if (i > 7) { break }           // 超过 7 停
  log(str(i))                    // 1 3 5 7
}
```

### S. 字符串扩展

```
log(format("用户 {0} 的积分是 {1}", ["小明", 1024]))
log(padRight(str(42), 5, "0"))            // 42000
log(join(words("a  b   c"), "-"))         // a-b-c
log(repeatStr("ha", 3))                   // hahaha
```

### T. JSON 调试

```
let cfg = jsonDecode("{\"vip\":true,\"level\":3}")
let s = ""
for (let k in cfg) { s = s + k + "=" + str(cfg[k]) + " " }
log(s)                    // level=3 vip=1（字典顺序不定）
log(jsonEncode(cfg))      // 转回 JSON 字符串
```

### U. 数学函数算返回值

覆盖类型 = 自定义脚本：

```
let score = clamp(int(original) + 10, 0, 100)   // 夹到 0～100
let bonus = lerp(0, 50, 0.5)                    // 25
round(score + bonus)
```

### V. 循环里逐个处理子视图

挂在某个视图的布局方法上（比如 layoutSubviews），把前 10 个子视图里的按钮都调淡：

```
let total = subviewCount(self)
for (let i = 0; i < total && i < 10; i = i + 1) {
  let v = subview(self, i)
  if (classname(v) == "UIButton") {
    alpha(v, 0.3)
  }
}
```

查找类函数只能在主线程用，所以这条规则要挂在主线程会被调的方法上；subview 越界给空值不报错，循环里先用 classname(v) 过滤再动手。

### W. 试算 / 生成 ID（1.2.6）

试算页直接跑：

```
uuid()
```

就能得到一串 UUID；要多条用 randomString(16)：

```
randomString(16)
```

### X. 处理时间

```
log(yyyy() + "-" + mm() + "-" + dd() + " " + weekday())
log(formatDate(timestamp(), "yyyy-MM-dd HH:mm"))
log(timeAgo(timestamp() - 3600))     // 1 小时前
```

---

## 八、怎么调试

1. 试算一次：编辑页右上角。它先查语法，再让你手填 original、arg1、arg2...、hits，然后可以选
   - 真跑一次：在应用修改器自己进程里真的执行，toast / vibrate 能看到效果；
   - 只检查语法：只算不做事。
   注意试算时 self 是空的，涉及 self 的语句结果会是空值，这是正常的。
   结果弹窗和报错弹窗都有「复制内容」，可以把整段（含第几行第几列）拷出来。
2. 看日志：注入状态页 → 找到这条规则 → 会显示日志条数，点开看最近几条。每条规则最多留 50 条、每条 200 字。
3. 工具条：编辑页底部常驻一条（不是键盘上那条，所以跟输入法自带的工具栏、别的插件的键盘栏都不会
   打架），按钮「插入」（变量 / 动作 / 函数 / 整段范例 / 语法速查）、「缩进」、「行尾」、「Aa」（字号
   11→13→15→17 循环，记住上次的选择）、「收键盘」；键盘弹出时工具条和状态条一起往上移。
   左边灰色数字是行号，软换行的续行不给号，报错会告诉你第几行第几列。

---

## 九、限制与保护

- 单个脚本最多 8000 字，最多 400 句；超了保存时会提示。
- delay 最多 60 秒；random(小, 大) 要小的在前。
- 循环有 10 万次保护，超出自动停止并报「循环超过 10 万次，已自动停止」，不会卡死。
- 数组字面量、arr() / dict() / range() 等构造出来的是只读数组 / 字典；push / setKey / 下标赋值这类
  写入，只能用在本来就是可变的容器上（例如宿主对象提供的可变属性）。写不了会报中文错误，不会崩。
- 下标读取越界给空值不报错；下标写入越界会报「数组下标越界」。
- 语法写错：保存时会拦下并报行号。万一装进去了，注入端编译不过会把这条规则标成失败，但不会动原方法，
  也不影响同一个 App 的其它规则。
- 动作脚本连续出错 5 次会自动停掉这段脚本（避免一直拖慢应用），状态页能看到。
- 整段脚本被异常保护包着，宿主方法自己抛异常不会把进程带走。
- 不支持 += / -= / do...while / Math.* / 模板字符串这些标准 JS 写法，请按本说明书语法来（i++ / i-- 支持）。

---

## 十、常见问题

| 现象 | 原因 / 解法 |
| --- | --- |
| 7 / 2 得 3 | 两个整数相除得整数；要小数写 num(7) / 2 或 7 / num(2) |
| 报「这里不该出现"*"」 | 用了 /* */，改成 // |
| 报「没有 xx() 这个函数」 | 函数名写错了，或版本太旧没有这个函数；本文的函数表是 1.2.16 全集 |
| 报「没有 xx 这个变量」 | 内置的是 self / hits / cls / sel / argc / argN / original / now，别自己造名字 |
| 写 i += 1 报语法错 | 不支持 += / -=，改 i = i + 1 或 i++ |
| 写 tags.forEach(function(t) { … }) 报「多出来的内容 (」 | 1.2.11 及更早的解析器漏认了 forEach 的括号，升到 1.2.12 |
| 写 Math.floor 报语法错 | 数学用函数：floor(x)、abs(x)、sqrt(x) 等，见本文函数表 |
| original 一直是空 | 实施方式没选 `原方法后改返回值` |
| call 报冒号个数不对 | "setHidden:" 一个冒号配一个参数，"a:b:" 配两个 |
| 调了 UI 方法就闪退/没反应 | 用 delay(0, call(...)) 挪到主线程 |
| 脚本存了但没反应 | 规则没启用；或者目标 App 没杀掉重开 |
| 一震动就震个不停 | 方法太高频，加 if (hits == 1) 或 hits % 20 == 1 |
| 弹窗把应用弄卡了 | 别用 alert，换 toast |
| push / setKey 报「要可变数组 / 字典」 | 容器是只读的（字面量、arr() / dict() / range() 的结果都是只读副本），换宿主传来的可变容器操作 |
| 循环卡住不动 | 检查 for 的计数器是不是一直不变（比如写成了 i = i + 1 但条件没更新），10 万次会自己停 |

---

装完打开「应用修改器」→ 配规则 → 写脚本 → 保存 → 杀掉目标 App 重新打开 → 触发功能 → 回「注入状态」看日志。
改完脚本同样要杀掉目标 App 重开才生效。

## arg1、arg2... 与「参数改写」的先后顺序

规则编辑页里的「参数改写」在方法被调用的那一刻先生效，早于动作脚本与返回值脚本。
所以脚本里读到的 arg1、arg2... 已经是改写之后的值，原方法拿到的也是改写之后的值。
想看宿主原本传的是什么，就先别配这个参数的改写（选「不改」）。
结构体参数（CGRect 这类）改不了，装规则时会直接报中文错误；指针 / Class 参数只能改成「nil / 0」。