#!/bin/sh
# CNSWatchdog.sh — 看守狗启动脚本
# 自动检测 JB_ROOT 并启动 daemon watchdog 模式

# 检测 JB_ROOT (扫描 .jbroot-*)
JBROOT_BASE="/var/mobile/Containers/Shared/AppGroup"
for dir in "$JBROOT_BASE"/.jbroot-*; do
    if [ -d "$dir" ]; then
        export JB_ROOT="$dir"
        break
    fi
done

if [ -z "$JB_ROOT" ]; then
    echo "CNSWatchdog: 无法检测 JB_ROOT, 退出"
    exit 1
fi

exec /usr/libexec/CNSVibrationCacheDaemon --watchdog
