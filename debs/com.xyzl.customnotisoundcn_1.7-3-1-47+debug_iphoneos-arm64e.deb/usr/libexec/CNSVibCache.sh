#!/bin/sh
# CNSVibCache.sh — 读取 rootfs 振动 plist 并管道传给解析 daemon
# 由 LaunchDaemon 在开机时调用 (launchd 可正确解析 /usr/libexec/ 路径)
# V26.11-18: Tweak 改用 raw syscall 直读, 此脚本仅作 LaunchDaemon 备份

VIB_PLIST="/rootfs/var/mobile/Media/Vibrations/UserGeneratedVibrationPatterns.plist"

if [ -f "$VIB_PLIST" ]; then
    cat "$VIB_PLIST" | /usr/libexec/CNSVibrationCacheDaemon
fi
