go —— Theos 编译输出汉化包装器（原生二进制，arm64）

装好就能用，不用放进工程目录。

  cd 到工程目录（哪一层都行）
  go make                 等同 make package

常用：
  go                      等同 go make
  go make messages=yes    等同 make package messages=yes
  go clean                等同 make clean
  go make do v=1          等同 make do v=1

编译目录会自动找：当前目录 → 往上找 Theos 工程 → 往下找（最多 3 层）。
也可以手动指定：L10N_DIR=/var/mobile/Documents/Hook go make

make 的位置也是自动找的（不靠 PATH 猜）：先看 go 自己所在的目录，
再看 roothide 的 .jbroot-* 真实根、/var/jb/usr/bin、/usr/bin 等位置，
最后才查 PATH。找到了就用绝对路径执行。
找不到会列出试过的每个位置；make 装在特殊位置时可以指定：
  L10N_MAKE=/完整/路径/make go make

开关：
  L10N_OFF=1      关闭汉化，原样输出
  L10N_NO_PAUSE=1 结束后不等待回车
  L10N_QUIET=1    不打印「编译目录」提示

编译失败时返回码原样保留，不会被当成成功。
